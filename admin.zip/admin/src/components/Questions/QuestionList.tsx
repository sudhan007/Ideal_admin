import React from 'react'

const QuestionList = () => {
  return <div>QuestionList</div>
}

export default QuestionList
