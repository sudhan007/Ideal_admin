import { c as createLucideIcon } from "./router-nT5qf-VO.mjs";
const __iconNode = [
  ["path", { d: "M5 12h14", key: "1ays0h" }],
  ["path", { d: "M12 5v14", key: "s699le" }]
];
const Plus = createLucideIcon("plus", __iconNode);
export {
  Plus as P
};
