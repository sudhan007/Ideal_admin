import { jsx, jsxs } from "react/jsx-runtime";
import { N as NotFound, _ as _axios } from "./router-nT5qf-VO.mjs";
import { useState, useEffect, useRef } from "react";
import { useMutation } from "@tanstack/react-query";
import { useSearch } from "@tanstack/react-router";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "next-themes";
import "sonner";
import "@radix-ui/react-tooltip";
import "axios";
import "@radix-ui/react-label";
function CreateQuestion({
  courseId: propCourseId,
  lessonId: propLessonId,
  chapterId: propChapterId
} = {}) {
  const [selectedCourse, setSelectedCourse] = useState(propCourseId || "");
  const [selectedLesson, setSelectedLesson] = useState(propLessonId || "");
  const [questionType, setQuestionType] = useState("MCQ");
  const [questionData, setQuestionData] = useState({
    questionText: "",
    questionLatex: "",
    type: "MCQ",
    options: [
      { id: "A", answer: "" },
      { id: "B", answer: "" },
      { id: "C", answer: "" },
      { id: "D", answer: "" }
    ],
    correctAnswer: "",
    // For MCQ: stores option id (A, B, C, D), For others: stores actual answer
    correctAnswerLatex: "",
    // For math_input type
    difficulty: "MEDIUM",
    marks: 1
  });
  useEffect(() => {
    if (propCourseId) setSelectedCourse(propCourseId);
    if (propLessonId) setSelectedLesson(propLessonId);
  }, [propCourseId, propLessonId]);
  useEffect(() => {
    setQuestionData((prev) => ({
      ...prev,
      type: questionType,
      // Reset correct answer when type changes
      correctAnswer: "",
      correctAnswerLatex: ""
    }));
  }, [questionType]);
  const validateQuestion = () => {
    if (!selectedCourse || !selectedLesson || !propChapterId) {
      alert("Please ensure course, lesson, and chapter are provided.");
      return false;
    }
    if (!questionData.questionText.trim()) {
      alert("Please enter question text.");
      return false;
    }
    if (questionType === "MCQ") {
      const hasEmptyOption = questionData.options.some(
        (opt) => !opt.answer.trim()
      );
      if (hasEmptyOption) {
        alert("Please fill in all MCQ options.");
        return false;
      }
      if (!questionData.correctAnswer) {
        alert("Please select the correct answer.");
        return false;
      }
    } else if (questionType === "FILL_BLANK") {
      if (!questionData.correctAnswer.trim()) {
        alert("Please enter the correct answer.");
        return false;
      }
    } else if (questionType === "MATH_INPUT") {
      if (!questionData.correctAnswerLatex.trim()) {
        alert("Please enter the correct formula.");
        return false;
      }
    }
    return true;
  };
  const { mutate, isPending } = useMutation({
    mutationFn: async (data) => {
      console.log(data, "ereee");
      const res = await _axios.post("/question", data);
      console.log(res);
      return res.data;
    },
    onSuccess: (data) => {
      alert("Question created successfully!");
      resetForm();
    },
    onError: (error) => {
      alert(error.message || "Failed to save question");
    }
  });
  const saveQuestion = async () => {
    if (!validateQuestion()) return;
    const payload = {
      courseId: selectedCourse,
      lessonId: selectedLesson,
      chapterId: propChapterId,
      type: questionType,
      difficulty: questionData.difficulty,
      marks: questionData.marks,
      question: {
        text: questionData.questionText,
        ...questionData.questionLatex && {
          latex: questionData.questionLatex
        }
      },
      // For MCQ: include options array, For others: omit options
      ...questionType === "MCQ" && {
        options: questionData.options.filter((opt) => opt.answer.trim())
      },
      // correctAnswer handling:
      // - MCQ: option id (A, B, C, D)
      // - fill_blank: text answer
      // - math_input: latex formula
      correctAnswer: questionType === "MATH_INPUT" ? questionData.correctAnswerLatex : questionData.correctAnswer,
      isActive: true
    };
    mutate(payload);
  };
  const resetForm = () => {
    setQuestionData({
      questionText: "",
      questionLatex: "",
      type: "MCQ",
      options: [
        { id: "A", answer: "" },
        { id: "B", answer: "" },
        { id: "C", answer: "" },
        { id: "D", answer: "" }
      ],
      correctAnswer: "",
      correctAnswerLatex: "",
      difficulty: "MEDIUM",
      marks: 1
    });
    setQuestionType("MCQ");
  };
  return /* @__PURE__ */ jsx("div", { className: "min-h-screen bg-gray-50 px-4 py-8", children: /* @__PURE__ */ jsx("div", { className: "max-w-5xl mx-auto", children: /* @__PURE__ */ jsxs("div", { className: "bg-white rounded-2xl shadow-lg overflow-hidden", children: [
    /* @__PURE__ */ jsxs("div", { className: "bg-gradient-to-r from-blue-600 to-indigo-600 px-8 py-6 text-white", children: [
      /* @__PURE__ */ jsx("h1", { className: "text-3xl font-bold", children: "Create New Question" }),
      /* @__PURE__ */ jsx("p", { className: "mt-2 text-blue-100", children: "Fill in the details to add a question to your course" })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "p-8 space-y-10", children: [
      /* @__PURE__ */ jsxs("section", { children: [
        /* @__PURE__ */ jsx("h2", { className: "text-2xl font-semibold text-gray-800 mb-5", children: "Question Type" }),
        /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsx(
            "button",
            {
              onClick: () => setQuestionType("MCQ"),
              className: `p-6 rounded-xl font-medium text-lg transition-all duration-200 shadow-md hover:shadow-lg ${questionType === "MCQ" ? "bg-blue-600 text-white ring-4 ring-blue-200" : "bg-white text-gray-700 border-2 border-gray-200 hover:border-blue-300"}`,
              children: "Multiple Choice"
            }
          ),
          /* @__PURE__ */ jsx(
            "button",
            {
              onClick: () => setQuestionType("FILL_BLANK"),
              className: `p-6 rounded-xl font-medium text-lg transition-all duration-200 shadow-md hover:shadow-lg ${questionType === "FILL_BLANK" ? "bg-blue-600 text-white ring-4 ring-blue-200" : "bg-white text-gray-700 border-2 border-gray-200 hover:border-blue-300"}`,
              children: "Fill in the Blanks"
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxs("section", { children: [
        /* @__PURE__ */ jsx("h2", { className: "text-2xl font-semibold text-gray-800 mb-5", children: "Question Content" }),
        /* @__PURE__ */ jsx("div", { className: "bg-gray-50 rounded-xl p-6 border border-gray-200", children: /* @__PURE__ */ jsx(
          MathQuestionEditor,
          {
            type: questionType,
            data: questionData,
            onChange: setQuestionData
          }
        ) })
      ] }),
      /* @__PURE__ */ jsxs("section", { children: [
        /* @__PURE__ */ jsx("h2", { className: "text-2xl font-semibold text-gray-800 mb-5", children: "Preview" }),
        /* @__PURE__ */ jsx("div", { className: "bg-gray-50 rounded-xl border-2 border-dashed border-gray-300 p-8", children: /* @__PURE__ */ jsx(QuestionPreview, { data: questionData, type: questionType }) })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex justify-end gap-4 pt-6", children: [
        /* @__PURE__ */ jsx(
          "button",
          {
            onClick: resetForm,
            disabled: isPending,
            className: "px-8 py-4 bg-gray-200 text-gray-700 text-lg font-semibold rounded-xl shadow hover:shadow-md hover:bg-gray-300 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed",
            children: "Reset"
          }
        ),
        /* @__PURE__ */ jsx(
          "button",
          {
            onClick: saveQuestion,
            disabled: isPending,
            className: "px-10 py-4 bg-gradient-to-r from-green-600 to-emerald-600 text-white text-lg font-semibold rounded-xl shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none",
            children: isPending ? "Saving..." : "Save Question"
          }
        )
      ] })
    ] })
  ] }) }) });
}
function SymbolButton({
  latex,
  display,
  onClick
}) {
  return /* @__PURE__ */ jsxs(
    "button",
    {
      onClick: () => onClick(latex),
      className: "flex items-center gap-2 px-5 py-3 bg-white hover:bg-blue-50 border border-gray-300 hover:border-blue-400 rounded-lg shadow-sm hover:shadow transition-all duration-200 group",
      title: `Insert ${display}`,
      children: [
        /* @__PURE__ */ jsx("span", { className: "text-lg font-medium text-gray-700", children: /* @__PURE__ */ jsx("math-field", { readonly: true, "fonts-directory": "/fonts", className: "text-base", children: latex }) }),
        /* @__PURE__ */ jsx("span", { className: "text-xs text-gray-500 group-hover:text-blue-600", children: display })
      ]
    }
  );
}
function MathQuestionEditor({
  type,
  data,
  onChange
}) {
  const questionMathRef = useRef(null);
  const answerMathRef = useRef(null);
  const insertSymbol = (mathRef, latex) => {
    if (mathRef.current) {
      mathRef.current.executeCommand(["insert", latex]);
      mathRef.current.focus();
    }
  };
  const setupKeyboard = (mf) => {
    if (mf) {
      mf.mathVirtualKeyboardPolicy = "manual";
      const showKB = () => window.mathVirtualKeyboard?.show();
      const hideKB = () => window.mathVirtualKeyboard?.hide();
      mf.addEventListener("focusin", showKB);
      mf.addEventListener("focusout", hideKB);
      return () => {
        mf.removeEventListener("focusin", showKB);
        mf.removeEventListener("focusout", hideKB);
      };
    }
  };
  useEffect(() => {
    const cleanupQuestion = setupKeyboard(questionMathRef.current);
    return cleanupQuestion;
  }, []);
  return /* @__PURE__ */ jsxs("div", { className: "space-y-8", children: [
    /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsxs("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: [
        "Question Text ",
        /* @__PURE__ */ jsx("span", { className: "text-red-500", children: "*" })
      ] }),
      /* @__PURE__ */ jsx(
        "textarea",
        {
          value: data.questionText,
          onChange: (e) => onChange({ ...data, questionText: e.target.value }),
          rows: 4,
          className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all resize-none",
          placeholder: "e.g., Find the value of x in the equation..."
        }
      )
    ] }),
    /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsx("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: "Question Formula (Optional)" }),
      /* @__PURE__ */ jsxs("div", { className: "mb-4 p-4 bg-blue-50/50 border border-blue-200 rounded-xl", children: [
        /* @__PURE__ */ jsx("p", { className: "text-sm font-medium text-blue-800 mb-3", children: "Quick Unit Vectors" }),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap gap-3", children: [
          /* @__PURE__ */ jsx(
            SymbolButton,
            {
              latex: "\\hat{i}",
              display: "i hat",
              onClick: (l) => insertSymbol(questionMathRef, l)
            }
          ),
          /* @__PURE__ */ jsx(
            SymbolButton,
            {
              latex: "\\hat{j}",
              display: "j hat",
              onClick: (l) => insertSymbol(questionMathRef, l)
            }
          ),
          /* @__PURE__ */ jsx(
            SymbolButton,
            {
              latex: "\\hat{k}",
              display: "k hat",
              onClick: (l) => insertSymbol(questionMathRef, l)
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "bg-white border-2 border-gray-200 rounded-xl p-5 shadow-sm", children: /* @__PURE__ */ jsx(
        "math-field",
        {
          ref: questionMathRef,
          className: "math-input-field w-full text-lg",
          onInput: (e) => onChange({ ...data, questionLatex: e.target.value }),
          children: data.questionLatex
        }
      ) }),
      /* @__PURE__ */ jsxs("p", { className: "mt-2 text-xs text-gray-500", children: [
        "Current LaTeX:",
        " ",
        /* @__PURE__ */ jsx("code", { className: "bg-gray-100 px-2 py-1 rounded", children: data.questionLatex || "empty" })
      ] })
    ] }),
    type === "MCQ" && /* @__PURE__ */ jsx(MCQEditor, { data, onChange }),
    type === "FILL_BLANK" && /* @__PURE__ */ jsx(FillBlankEditor, { data, onChange }),
    type === "MATH_INPUT" && /* @__PURE__ */ jsx(
      MathInputEditor,
      {
        data,
        onChange,
        answerMathRef,
        insertSymbol
      }
    ),
    /* @__PURE__ */ jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6", children: /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsx("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: "Difficulty Level" }),
      /* @__PURE__ */ jsxs(
        "select",
        {
          value: data.difficulty,
          onChange: (e) => onChange({ ...data, difficulty: e.target.value }),
          className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white",
          children: [
            /* @__PURE__ */ jsx("option", { value: "EASY", children: "Easy" }),
            /* @__PURE__ */ jsx("option", { value: "MEDIUM", children: "Medium" }),
            /* @__PURE__ */ jsx("option", { value: "HARD", children: "Hard" })
          ]
        }
      )
    ] }) })
  ] });
}
function MathInputEditor({
  data,
  onChange,
  answerMathRef,
  insertSymbol
}) {
  useEffect(() => {
    if (answerMathRef.current) {
      answerMathRef.current.mathVirtualKeyboardPolicy = "manual";
      const showKB = () => window.mathVirtualKeyboard?.show();
      const hideKB = () => window.mathVirtualKeyboard?.hide();
      answerMathRef.current.addEventListener("focusin", showKB);
      answerMathRef.current.addEventListener("focusout", hideKB);
      return () => {
        answerMathRef.current?.removeEventListener("focusin", showKB);
        answerMathRef.current?.removeEventListener("focusout", hideKB);
      };
    }
  }, []);
  return /* @__PURE__ */ jsxs("div", { children: [
    /* @__PURE__ */ jsxs("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: [
      "Correct Answer (Formula) ",
      /* @__PURE__ */ jsx("span", { className: "text-red-500", children: "*" })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "mb-4 p-4 bg-emerald-50/50 border border-emerald-200 rounded-xl", children: [
      /* @__PURE__ */ jsx("p", { className: "text-sm font-medium text-emerald-800 mb-3", children: "Quick Unit Vectors" }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-wrap gap-3", children: [
        /* @__PURE__ */ jsx(
          SymbolButton,
          {
            latex: "\\hat{i}",
            display: "i hat",
            onClick: (l) => insertSymbol(answerMathRef, l)
          }
        ),
        /* @__PURE__ */ jsx(
          SymbolButton,
          {
            latex: "\\hat{j}",
            display: "j hat",
            onClick: (l) => insertSymbol(answerMathRef, l)
          }
        ),
        /* @__PURE__ */ jsx(
          SymbolButton,
          {
            latex: "\\hat{k}",
            display: "k hat",
            onClick: (l) => insertSymbol(answerMathRef, l)
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "bg-white border-2 border-gray-200 rounded-xl p-5 shadow-sm", children: /* @__PURE__ */ jsx(
      "math-field",
      {
        ref: answerMathRef,
        className: "math-input-field w-full text-lg",
        onInput: (e) => {
          const latex = e.target.value;
          onChange({
            ...data,
            correctAnswerLatex: latex
          });
        },
        children: data.correctAnswerLatex
      }
    ) }),
    /* @__PURE__ */ jsxs("p", { className: "mt-3 text-xs text-gray-500", children: [
      "Current LaTeX:",
      " ",
      /* @__PURE__ */ jsx("code", { className: "bg-gray-100 px-2 py-1 rounded", children: data.correctAnswerLatex || "empty" })
    ] })
  ] });
}
function MCQEditor({
  data,
  onChange
}) {
  const updateOption = (index, value) => {
    const options = [...data.options];
    options[index].answer = value;
    onChange({ ...data, options });
  };
  const selectCorrectAnswer = (optionId) => {
    onChange({ ...data, correctAnswer: optionId });
  };
  return /* @__PURE__ */ jsxs("div", { children: [
    /* @__PURE__ */ jsxs("label", { className: "block text-sm font-semibold text-gray-700 mb-4", children: [
      "Options ",
      /* @__PURE__ */ jsx("span", { className: "text-red-500", children: "*" })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "space-y-4", children: data.options.map((opt, i) => /* @__PURE__ */ jsxs(
      "div",
      {
        className: "flex items-center gap-4 p-4 bg-gray-50 rounded-xl border border-gray-200",
        children: [
          /* @__PURE__ */ jsxs("span", { className: "font-bold text-lg text-gray-600 w-10", children: [
            opt.id,
            "."
          ] }),
          /* @__PURE__ */ jsx(
            "input",
            {
              type: "text",
              value: opt.answer,
              onChange: (e) => updateOption(i, e.target.value),
              className: "flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500",
              placeholder: `Option ${opt.id}`
            }
          ),
          /* @__PURE__ */ jsxs("label", { className: "flex items-center gap-2 cursor-pointer", children: [
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "radio",
                name: "correct",
                checked: data.correctAnswer === opt.id,
                onChange: () => selectCorrectAnswer(opt.id),
                className: "w-5 h-5 text-blue-600"
              }
            ),
            /* @__PURE__ */ jsx("span", { className: "text-sm font-medium text-gray-700", children: "Correct" })
          ] })
        ]
      },
      opt.id
    )) })
  ] });
}
function FillBlankEditor({
  data,
  onChange
}) {
  return /* @__PURE__ */ jsxs("div", { children: [
    /* @__PURE__ */ jsxs("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: [
      "Correct Answer (Text) ",
      /* @__PURE__ */ jsx("span", { className: "text-red-500", children: "*" })
    ] }),
    /* @__PURE__ */ jsx(
      "input",
      {
        type: "text",
        value: data.correctAnswer,
        onChange: (e) => onChange({ ...data, correctAnswer: e.target.value }),
        className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500",
        placeholder: "Enter the correct answer"
      }
    )
  ] });
}
function QuestionPreview({ data, type }) {
  return /* @__PURE__ */ jsxs("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsx("p", { className: "text-sm font-semibold text-gray-500 mb-2", children: "Question:" }),
      /* @__PURE__ */ jsx("p", { className: "text-lg text-gray-800 leading-relaxed", children: data.questionText || /* @__PURE__ */ jsx("em", { className: "text-gray-400", children: "No question text" }) })
    ] }),
    data.questionLatex && /* @__PURE__ */ jsx("div", { className: "p-6 bg-blue-50 rounded-xl border border-blue-200", children: /* @__PURE__ */ jsx("math-field", { readonly: true, className: "text-xl", children: data.questionLatex }) }),
    type === "MCQ" && /* @__PURE__ */ jsxs("div", { className: "space-y-3", children: [
      /* @__PURE__ */ jsx("p", { className: "text-sm font-semibold text-gray-500 mb-2", children: "Options:" }),
      data.options.map((opt) => /* @__PURE__ */ jsxs(
        "div",
        {
          className: `p-5 rounded-xl border-2 transition-all ${opt.id === data.correctAnswer ? "bg-green-50 border-green-400 shadow-sm" : "bg-white border-gray-200"}`,
          children: [
            /* @__PURE__ */ jsxs("strong", { className: "text-lg mr-3", children: [
              opt.id,
              "."
            ] }),
            /* @__PURE__ */ jsx("span", { className: "text-gray-800", children: opt.answer || /* @__PURE__ */ jsx("em", { className: "text-gray-400", children: "Empty option" }) }),
            opt.id === data.correctAnswer && /* @__PURE__ */ jsx("span", { className: "ml-3 text-sm text-green-600 font-semibold", children: "✓ Correct" })
          ]
        },
        opt.id
      ))
    ] }),
    type === "FILL_BLANK" && /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsx("p", { className: "text-sm font-semibold text-gray-500 mb-2", children: "Correct Answer:" }),
      /* @__PURE__ */ jsx("div", { className: "p-4 bg-green-50 rounded-xl border border-green-200", children: /* @__PURE__ */ jsx("span", { className: "text-lg text-gray-800 font-medium", children: data.correctAnswer || /* @__PURE__ */ jsx("em", { className: "text-gray-400", children: "—" }) }) })
    ] }),
    type === "MATH_INPUT" && /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsx("p", { className: "text-sm font-semibold text-gray-500 mb-2", children: "Expected Formula:" }),
      /* @__PURE__ */ jsx("div", { className: "p-6 bg-emerald-50 rounded-xl border-2 border-emerald-200", children: /* @__PURE__ */ jsx("math-field", { readonly: true, className: "text-xl", children: data.correctAnswerLatex || "\\phantom{empty}" }) })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-6 pt-4 border-t border-gray-200", children: [
      /* @__PURE__ */ jsxs("p", { className: "text-sm text-gray-600", children: [
        /* @__PURE__ */ jsx("strong", { children: "Difficulty:" }),
        " ",
        /* @__PURE__ */ jsx("span", { className: "px-3 py-1 bg-gray-200 rounded-full capitalize font-medium", children: data.difficulty })
      ] }),
      /* @__PURE__ */ jsxs("p", { className: "text-sm text-gray-600", children: [
        /* @__PURE__ */ jsx("strong", { children: "Marks:" }),
        " ",
        /* @__PURE__ */ jsx("span", { className: "px-3 py-1 bg-gray-200 rounded-full font-medium", children: data.marks })
      ] })
    ] })
  ] });
}
const QuestionList = () => {
  return /* @__PURE__ */ jsx("div", { children: "QuestionList" });
};
function RouteComponent() {
  const search = useSearch({
    from: "/questions/"
  });
  const {
    mode,
    chapterId,
    courseId,
    lessonId
  } = search;
  if (!chapterId || !courseId || !lessonId) {
    return null;
  }
  if (mode === "create") {
    return /* @__PURE__ */ jsx(CreateQuestion, { courseId, lessonId, chapterId });
  }
  if (mode === "list") {
    return /* @__PURE__ */ jsx(QuestionList, {});
  }
  return /* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx(NotFound, {}) });
}
export {
  RouteComponent as component
};
