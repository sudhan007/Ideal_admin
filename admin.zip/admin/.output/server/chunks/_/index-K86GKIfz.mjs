import { jsxs, jsx } from "react/jsx-runtime";
import { useQuery } from "@tanstack/react-query";
import { R as Route$5, _ as _axios, B as Button } from "./router-nT5qf-VO.mjs";
import { useReactTable, getPaginationRowModel, getFilteredRowModel, getSortedRowModel, getCoreRowModel, flexRender } from "@tanstack/react-table";
import { useState } from "react";
import { useSearch } from "@tanstack/react-router";
import { I as Input } from "./input-B5eCZYSF.mjs";
import { C as CourseTableSkeleton, a as ChevronLeft, b as ChevronRight } from "./TableSkeleton-D58uHf2v.mjs";
import { P as Plus } from "./plus.mjs";
import { P as Pencil } from "./pencil.mjs";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "next-themes";
import "sonner";
import "@radix-ui/react-tooltip";
import "axios";
import "@radix-ui/react-label";
function MentorsPage() {
  const navigate = Route$5.useNavigate();
  const search = useSearch({
    from: "/mentors/"
  });
  const {
    page = 1,
    search: searchTerm = "",
    sortBy = "createdAt",
    sortOrder = "desc"
  } = search;
  const [sorting, setSorting] = useState([{
    id: sortBy,
    desc: sortOrder === "desc"
  }]);
  const [columnFilters, setColumnFilters] = useState([]);
  const [columnVisibility, setColumnVisibility] = useState({});
  const {
    data,
    isLoading
  } = useQuery({
    queryKey: ["mentors", {
      page,
      search: searchTerm,
      sortBy,
      sortOrder
    }],
    queryFn: async () => {
      const params = new URLSearchParams({
        page: String(page),
        limit: "10",
        search: searchTerm,
        sortBy,
        sortOrder
      });
      const res = await _axios.get(`/staffs?${params.toString()}`);
      return res.data;
    }
  });
  console.log(data, "data");
  const staffs = data?.staffs ?? [];
  const pagination = data?.pagination;
  const columns = [{
    accessorKey: "mentor.staffName",
    header: "Mentor",
    cell: ({
      row
    }) => /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
      /* @__PURE__ */ jsx("img", { src: row.original.image, alt: row.original.staffName, className: "h-10 w-10 rounded-full object-cover" }),
      /* @__PURE__ */ jsx("span", { children: row.original.staffName })
    ] })
  }, {
    accessorKey: "phoneNumber",
    header: "Phone Number",
    cell: ({
      row
    }) => /* @__PURE__ */ jsx("div", { className: "font-medium", children: row.original.phoneNumber })
  }, {
    id: "actions",
    header: "Actions",
    cell: ({
      row
    }) => {
      const mentor = row.original;
      return /* @__PURE__ */ jsx("div", { className: "flex items-center gap-2", children: /* @__PURE__ */ jsx("button", { onClick: () => navigate({
        to: `/mentors/$id`,
        params: {
          id: mentor._id
        },
        state: {
          mentor
        }
      }), className: "p-2 rounded-md cursor-pointer text-foreground transition-colors", title: "Edit Mentor", children: /* @__PURE__ */ jsx(Pencil, { className: "h-4 w-4 text-foreground" }) }) });
    }
  }];
  const table = useReactTable({
    data: staffs,
    columns,
    onSortingChange: setSorting,
    onColumnFiltersChange: setColumnFilters,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    state: {
      sorting,
      columnFilters,
      columnVisibility
    },
    manualPagination: true,
    pageCount: pagination?.totalPages ?? -1
  });
  return /* @__PURE__ */ jsxs("div", { className: " mx-auto p-2", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex justify-end gap-3", children: [
      /* @__PURE__ */ jsx(Input, { type: "text", name: "mentor-search", placeholder: "Search mentors...", value: searchTerm, onChange: (e) => navigate({
        search: (prev) => ({
          ...prev,
          search: e.target.value,
          page: 1
        }),
        replace: true
      }), className: "mb-6 w-full max-w-sm border border-foreground px-4 py-2 \n             focus-visible:outline-none focus-visible:ring-0 focus-visible:shadow-none \n             focus-visible::border-none transition-colors h-10 rounded-xsm" }),
      /* @__PURE__ */ jsxs(Button, { onClick: () => navigate({
        to: "/mentors/$id",
        params: {
          id: "new"
        }
      }), className: "h-10 cursor-pointer text-background rounded-xsm", children: [
        /* @__PURE__ */ jsx(Plus, {}),
        " Create Mentor"
      ] })
    ] }),
    isLoading ? /* @__PURE__ */ jsx(CourseTableSkeleton, {}) : /* @__PURE__ */ jsx("div", { className: "rounded-xsm  bg-sidebar shadow-sm", children: /* @__PURE__ */ jsxs("table", { className: "w-full table-auto", children: [
      /* @__PURE__ */ jsx("thead", { className: "border-b ", children: table.getHeaderGroups().map((headerGroup) => /* @__PURE__ */ jsx("tr", { children: headerGroup.headers.map((header) => /* @__PURE__ */ jsx("th", { className: "px-3 py-4 text-left border-[0.5px] border-background text-sm font-medium text-foreground", children: header.isPlaceholder ? null : flexRender(header.column.columnDef.header, header.getContext()) }, header.id)) }, headerGroup.id)) }),
      /* @__PURE__ */ jsx("tbody", { children: table.getRowModel().rows.length === 0 ? /* @__PURE__ */ jsx("tr", { children: /* @__PURE__ */ jsx("td", { colSpan: columns.length, className: "px-6 py-12 text-center text-foreground", children: "No Staff found" }) }) : table.getRowModel().rows.map((row) => /* @__PURE__ */ jsx("tr", { className: " hover:bg-background", children: row.getVisibleCells().map((cell) => /* @__PURE__ */ jsx("td", { className: "px-3 py-2 border-[0.5px] border-background hover:bg-secondary-background", children: flexRender(cell.column.columnDef.cell, cell.getContext()) }, cell.id)) }, row.id)) })
    ] }) }),
    pagination && pagination.totalPages > 1 && /* @__PURE__ */ jsxs("div", { className: "mt-6 flex items-center justify-between", children: [
      /* @__PURE__ */ jsxs("div", { className: "text-sm text-gray-600", children: [
        "Showing page ",
        pagination.page,
        " of ",
        pagination.totalPages,
        " (",
        pagination.total,
        " total)"
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex gap-2", children: [
        /* @__PURE__ */ jsxs("button", { onClick: () => navigate({
          search: (prev) => ({
            ...prev,
            page: page - 1
          })
        }), disabled: !pagination.hasPrevPage, className: "flex items-center gap-2 rounded-lg border px-4 py-2 disabled:cursor-not-allowed disabled:opacity-50 hover:bg-gray-50", children: [
          /* @__PURE__ */ jsx(ChevronLeft, { className: "h-4 w-4" }),
          "Previous"
        ] }),
        /* @__PURE__ */ jsxs("button", { onClick: () => navigate({
          search: (prev) => ({
            ...prev,
            page: page + 1
          })
        }), disabled: !pagination.hasNextPage, className: "flex items-center gap-2 rounded-lg border px-4 py-2 disabled:cursor-not-allowed disabled:opacity-50 hover:bg-gray-50", children: [
          "Next",
          /* @__PURE__ */ jsx(ChevronRight, { className: "h-4 w-4" })
        ] })
      ] })
    ] })
  ] });
}
export {
  MentorsPage as component
};
