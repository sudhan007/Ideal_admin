import { c as createLucideIcon } from "./router-nT5qf-VO.mjs";
const __iconNode = [["path", { d: "m6 9 6 6 6-6", key: "qrunsl" }]];
const ChevronDown = createLucideIcon("chevron-down", __iconNode);
export {
  ChevronDown as C
};
