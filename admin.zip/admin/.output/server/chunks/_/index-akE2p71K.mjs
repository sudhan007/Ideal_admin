import { jsx, jsxs } from "react/jsx-runtime";
import { c as createLucideIcon, h as Route, _ as _axios, B as Button, L as Label, b as cn, i as buttonVariants } from "./router-nT5qf-VO.mjs";
import { useQueryClient, useQuery, useMutation } from "@tanstack/react-query";
import { useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { D as Dialog, a as DialogTrigger, b as DialogContent, c as DialogHeader, d as DialogTitle, f as DialogFooter } from "./dialog-BnYcus8l.mjs";
import { I as Input } from "./input-B5eCZYSF.mjs";
import * as AlertDialogPrimitive from "@radix-ui/react-alert-dialog";
import * as AccordionPrimitive from "@radix-ui/react-accordion";
import { toast } from "sonner";
import { P as Plus } from "./plus.mjs";
import { C as ChevronDown } from "./chevron-down.mjs";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "next-themes";
import "@radix-ui/react-tooltip";
import "axios";
import "@radix-ui/react-label";
import "@radix-ui/react-dialog";
const __iconNode$4 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3", key: "1u773s" }],
  ["path", { d: "M12 17h.01", key: "p32p05" }]
];
const CircleQuestionMark = createLucideIcon("circle-question-mark", __iconNode$4);
const __iconNode$3 = [
  ["path", { d: "M12 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7", key: "1m0v6g" }],
  [
    "path",
    {
      d: "M18.375 2.625a1 1 0 0 1 3 3l-9.013 9.014a2 2 0 0 1-.853.505l-2.873.84a.5.5 0 0 1-.62-.62l.84-2.873a2 2 0 0 1 .506-.852z",
      key: "ohrbg2"
    }
  ]
];
const SquarePen = createLucideIcon("square-pen", __iconNode$3);
const __iconNode$2 = [
  ["circle", { cx: "9", cy: "12", r: "3", key: "u3jwor" }],
  ["rect", { width: "20", height: "14", x: "2", y: "5", rx: "7", key: "g7kal2" }]
];
const ToggleLeft = createLucideIcon("toggle-left", __iconNode$2);
const __iconNode$1 = [
  ["circle", { cx: "15", cy: "12", r: "3", key: "1afu0r" }],
  ["rect", { width: "20", height: "14", x: "2", y: "5", rx: "7", key: "g7kal2" }]
];
const ToggleRight = createLucideIcon("toggle-right", __iconNode$1);
const __iconNode = [
  ["path", { d: "M10 11v6", key: "nco0om" }],
  ["path", { d: "M14 11v6", key: "outv1u" }],
  ["path", { d: "M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6", key: "miytrc" }],
  ["path", { d: "M3 6h18", key: "d0wm0j" }],
  ["path", { d: "M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2", key: "e791ji" }]
];
const Trash2 = createLucideIcon("trash-2", __iconNode);
function AlertDialog({
  ...props
}) {
  return /* @__PURE__ */ jsx(AlertDialogPrimitive.Root, { "data-slot": "alert-dialog", ...props });
}
function AlertDialogTrigger({
  ...props
}) {
  return /* @__PURE__ */ jsx(AlertDialogPrimitive.Trigger, { "data-slot": "alert-dialog-trigger", ...props });
}
function AlertDialogPortal({
  ...props
}) {
  return /* @__PURE__ */ jsx(AlertDialogPrimitive.Portal, { "data-slot": "alert-dialog-portal", ...props });
}
function AlertDialogOverlay({
  className,
  ...props
}) {
  return /* @__PURE__ */ jsx(
    AlertDialogPrimitive.Overlay,
    {
      "data-slot": "alert-dialog-overlay",
      className: cn(
        "data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 fixed inset-0 z-50 bg-black/50",
        className
      ),
      ...props
    }
  );
}
function AlertDialogContent({
  className,
  ...props
}) {
  return /* @__PURE__ */ jsxs(AlertDialogPortal, { children: [
    /* @__PURE__ */ jsx(AlertDialogOverlay, {}),
    /* @__PURE__ */ jsx(
      AlertDialogPrimitive.Content,
      {
        "data-slot": "alert-dialog-content",
        className: cn(
          "bg-background data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 fixed top-[50%] left-[50%] z-50 grid w-full max-w-[calc(100%-2rem)] translate-x-[-50%] translate-y-[-50%] gap-4 rounded-lg border p-6 shadow-lg duration-200 sm:max-w-lg",
          className
        ),
        ...props
      }
    )
  ] });
}
function AlertDialogHeader({
  className,
  ...props
}) {
  return /* @__PURE__ */ jsx(
    "div",
    {
      "data-slot": "alert-dialog-header",
      className: cn("flex flex-col gap-2 text-center sm:text-left", className),
      ...props
    }
  );
}
function AlertDialogFooter({
  className,
  ...props
}) {
  return /* @__PURE__ */ jsx(
    "div",
    {
      "data-slot": "alert-dialog-footer",
      className: cn(
        "flex flex-col-reverse gap-2 sm:flex-row sm:justify-end",
        className
      ),
      ...props
    }
  );
}
function AlertDialogTitle({
  className,
  ...props
}) {
  return /* @__PURE__ */ jsx(
    AlertDialogPrimitive.Title,
    {
      "data-slot": "alert-dialog-title",
      className: cn("text-lg font-semibold", className),
      ...props
    }
  );
}
function AlertDialogDescription({
  className,
  ...props
}) {
  return /* @__PURE__ */ jsx(
    AlertDialogPrimitive.Description,
    {
      "data-slot": "alert-dialog-description",
      className: cn("text-muted-foreground text-sm", className),
      ...props
    }
  );
}
function AlertDialogAction({
  className,
  ...props
}) {
  return /* @__PURE__ */ jsx(
    AlertDialogPrimitive.Action,
    {
      className: cn(buttonVariants(), className),
      ...props
    }
  );
}
function AlertDialogCancel({
  className,
  ...props
}) {
  return /* @__PURE__ */ jsx(
    AlertDialogPrimitive.Cancel,
    {
      className: cn(buttonVariants({ variant: "outline" }), className),
      ...props
    }
  );
}
function Accordion({
  ...props
}) {
  return /* @__PURE__ */ jsx(AccordionPrimitive.Root, { "data-slot": "accordion", ...props });
}
function AccordionItem({
  className,
  ...props
}) {
  return /* @__PURE__ */ jsx(
    AccordionPrimitive.Item,
    {
      "data-slot": "accordion-item",
      className: cn("border-b last:border-b-0", className),
      ...props
    }
  );
}
function AccordionTrigger({
  className,
  children,
  ...props
}) {
  return /* @__PURE__ */ jsx(AccordionPrimitive.Header, { className: "flex", children: /* @__PURE__ */ jsxs(
    AccordionPrimitive.Trigger,
    {
      "data-slot": "accordion-trigger",
      className: cn(
        "focus-visible:border-ring focus-visible:ring-ring/50 flex flex-1 items-start justify-between gap-4 rounded-md py-4 text-left text-sm font-medium transition-all outline-none hover:underline focus-visible:ring-[3px] disabled:pointer-events-none disabled:opacity-50 [&[data-state=open]>svg]:rotate-180",
        className
      ),
      ...props,
      children: [
        children,
        /* @__PURE__ */ jsx(ChevronDown, { className: "text-muted-foreground pointer-events-none size-4 shrink-0 translate-y-0.5 transition-transform duration-200" })
      ]
    }
  ) });
}
function AccordionContent({
  className,
  children,
  ...props
}) {
  return /* @__PURE__ */ jsx(
    AccordionPrimitive.Content,
    {
      "data-slot": "accordion-content",
      className: "data-[state=closed]:animate-accordion-up data-[state=open]:animate-accordion-down overflow-hidden text-sm",
      ...props,
      children: /* @__PURE__ */ jsx("div", { className: cn("pt-0 pb-4", className), children })
    }
  );
}
function RouteComponent() {
  const {
    id: courseId,
    chapterId
  } = Route.useParams();
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [editingLesson, setEditingLesson] = useState(null);
  const {
    data: lessons = [],
    isLoading
  } = useQuery({
    queryKey: ["lessons", chapterId],
    queryFn: async () => {
      if (!chapterId || chapterId === "new") return [];
      const res = await _axios.get(`/lessons/${chapterId}`);
      return res.data.lessons || res.data || [];
    },
    enabled: !!chapterId && chapterId !== "new"
  });
  const createMutation = useMutation({
    mutationFn: (data) => _axios.post("/lessons", {
      ...data,
      courseId,
      chapterId
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["lessons", chapterId]
      });
      setIsCreateOpen(false);
      toast.success("Lesson created successfully");
    },
    onError: () => toast.error("Failed to create lesson")
  });
  const updateMutation = useMutation({
    mutationFn: ({
      lessonId,
      data
    }) => _axios.put(`/lessons/${lessonId}`, {
      ...data,
      courseId,
      chapterId
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["lessons", chapterId]
      });
      setIsEditOpen(false);
      toast.success("Lesson updated successfully");
    }
  });
  const toggleStatusMutation = useMutation({
    mutationFn: (lessonId) => _axios.patch(`/lessons/${lessonId}`),
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["lessons", chapterId]
      });
      toast.success("Lesson status updated successfully");
    }
  });
  const deleteMutation = useMutation({
    mutationFn: (lessonId) => _axios.delete(`/lessons/${lessonId}`),
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["lessons", chapterId]
      });
      toast.success("Lesson deleted successfully");
    }
  });
  const handleCreate = (e) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const data = {
      lessonName: formData.get("lessonName"),
      order: Number(formData.get("order")),
      duration: Number(formData.get("duration")),
      videoUrl: formData.get("videoUrl")
    };
    createMutation.mutate(data);
  };
  const handleUpdate = (e) => {
    e.preventDefault();
    if (!editingLesson) return;
    const formData = new FormData(e.currentTarget);
    const data = {
      lessonName: formData.get("lessonName"),
      order: Number(formData.get("order")),
      duration: Number(formData.get("duration")),
      videoUrl: formData.get("videoUrl")
    };
    updateMutation.mutate({
      lessonId: editingLesson._id,
      data
    });
  };
  const openEdit = (lesson) => {
    setEditingLesson(lesson);
    setIsEditOpen(true);
  };
  if (isLoading) return /* @__PURE__ */ jsx("div", { className: "p-8 text-center", children: "Loading lessons..." });
  return /* @__PURE__ */ jsxs("div", { className: "", children: [
    /* @__PURE__ */ jsxs("header", { className: "flex justify-between items-center p-4  text-foreground", children: [
      /* @__PURE__ */ jsx("h5", { className: "font-medium font-nunito", children: "Lessons" }),
      /* @__PURE__ */ jsxs(Dialog, { open: isCreateOpen, onOpenChange: setIsCreateOpen, children: [
        /* @__PURE__ */ jsx(DialogTrigger, { asChild: true, children: /* @__PURE__ */ jsxs(Button, { className: "rounded-xsm cursor-pointer", children: [
          /* @__PURE__ */ jsx(Plus, { className: "mr-2 h-4 w-4" }),
          " Add Lesson"
        ] }) }),
        /* @__PURE__ */ jsxs(DialogContent, { autoFocus: false, children: [
          /* @__PURE__ */ jsx(DialogHeader, { children: /* @__PURE__ */ jsx(DialogTitle, { children: "Create New Lesson" }) }),
          /* @__PURE__ */ jsxs("form", { onSubmit: handleCreate, children: [
            /* @__PURE__ */ jsxs("div", { className: "grid gap-4 py-4", children: [
              /* @__PURE__ */ jsxs("div", { className: "grid gap-2", children: [
                /* @__PURE__ */ jsx(Label, { htmlFor: "lessonName", children: "Lesson Name" }),
                /* @__PURE__ */ jsx(Input, { type: "text", autoFocus: false, id: "lessonName", name: "lessonName", required: true })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "grid gap-2", children: [
                /* @__PURE__ */ jsx(Label, { htmlFor: "duration", children: "Duration" }),
                /* @__PURE__ */ jsx(Input, { id: "duration", name: "duration", type: "number", required: true })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "grid gap-2", children: [
                /* @__PURE__ */ jsx(Label, { htmlFor: "order", children: "Order" }),
                /* @__PURE__ */ jsx(Input, { id: "order", name: "order", type: "number", defaultValue: lessons.length + 1, required: true })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "grid gap-2", children: [
                /* @__PURE__ */ jsx(Label, { htmlFor: "videoUrl", children: "Video URL" }),
                /* @__PURE__ */ jsx(Input, { id: "videoUrl", name: "videoUrl", placeholder: "https://..." })
              ] })
            ] }),
            /* @__PURE__ */ jsx(DialogFooter, { children: /* @__PURE__ */ jsx(Button, { type: "submit", disabled: createMutation.isPending, children: "Create" }) })
          ] })
        ] })
      ] })
    ] }),
    lessons.length === 0 ? /* @__PURE__ */ jsx("div", { className: "flex items-center justify-center h-64 text-muted-foreground", children: /* @__PURE__ */ jsx("p", { children: "No lessons found. Add one to get started!" }) }) : /* @__PURE__ */ jsx(Accordion, { type: "single", collapsible: true, className: "w-full px-2 pt-2", children: lessons.map((lesson) => /* @__PURE__ */ jsxs(AccordionItem, { value: lesson._id, className: `mb-2 bg-accent hover:bg-foreground/10 rounded-xsm border-none! overflow-hidden ${!lesson.isActive ? "opacity-60" : ""}`, children: [
      /* @__PURE__ */ jsx(AccordionTrigger, { className: `px-4 py-3 hover:no-underline hover:bg-accent/50 border-none! transition-colors cursor-pointer ${!lesson.isActive ? "text-muted-foreground" : ""}`, children: /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between w-full pr-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3 text-left", children: [
          /* @__PURE__ */ jsx("span", { className: "font-medium capitalize text-foreground", children: lesson.lessonName }),
          /* @__PURE__ */ jsxs("span", { className: "text-sm text-muted-foreground", children: [
            "(Order: ",
            lesson.order,
            ")"
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", onClick: (e) => e.stopPropagation(), children: [
          /* @__PURE__ */ jsxs(Button, { variant: "outline", size: "sm", onClick: () => {
            navigate({
              to: "/questions",
              search: {
                lessonId: lesson._id,
                courseId,
                chapterId,
                mode: "create"
              }
            });
          }, className: "gap-1.5", children: [
            /* @__PURE__ */ jsx(CircleQuestionMark, { className: "h-4 w-4" }),
            "Add Questions"
          ] }),
          /* @__PURE__ */ jsx(Button, { variant: "ghost", size: "icon", onClick: () => openEdit(lesson), children: /* @__PURE__ */ jsx(SquarePen, { className: "h-4 w-4" }) }),
          /* @__PURE__ */ jsx(Button, { variant: "ghost", size: "icon", onClick: () => toggleStatusMutation.mutate(lesson._id), disabled: toggleStatusMutation.isPending, children: lesson.isActive ? /* @__PURE__ */ jsx(ToggleRight, { className: "h-5 w-5 text-green-600" }) : /* @__PURE__ */ jsx(ToggleLeft, { className: "h-5 w-5 text-red-600" }) }),
          /* @__PURE__ */ jsxs(AlertDialog, { children: [
            /* @__PURE__ */ jsx(AlertDialogTrigger, { asChild: true, children: /* @__PURE__ */ jsx(Button, { variant: "ghost", size: "icon", children: /* @__PURE__ */ jsx(Trash2, { className: "h-4 w-4 text-destructive" }) }) }),
            /* @__PURE__ */ jsxs(AlertDialogContent, { children: [
              /* @__PURE__ */ jsxs(AlertDialogHeader, { children: [
                /* @__PURE__ */ jsxs(AlertDialogTitle, { children: [
                  'Delete "',
                  lesson.lessonName,
                  '"?'
                ] }),
                /* @__PURE__ */ jsx(AlertDialogDescription, { children: "This action will permanently remove the lesson and its questions." })
              ] }),
              /* @__PURE__ */ jsxs(AlertDialogFooter, { children: [
                /* @__PURE__ */ jsx(AlertDialogCancel, { children: "Cancel" }),
                /* @__PURE__ */ jsx(AlertDialogAction, { onClick: () => deleteMutation.mutate(lesson._id), className: "bg-destructive text-destructive-foreground", children: "Delete" })
              ] })
            ] })
          ] })
        ] })
      ] }) }),
      /* @__PURE__ */ jsx(AccordionContent, { className: "px-4 pb-4 pt-2 text-foreground ", children: /* @__PURE__ */ jsxs("div", { className: "space-y-2 text-sm", children: [
        /* @__PURE__ */ jsxs("p", { children: [
          /* @__PURE__ */ jsx("span", { className: "font-medium", children: "Status:" }),
          " ",
          lesson.isActive ? /* @__PURE__ */ jsx("span", { className: "text-green-600", children: "Active" }) : /* @__PURE__ */ jsx("span", { className: "text-red-600", children: "Inactive" })
        ] }),
        /* @__PURE__ */ jsxs("p", { children: [
          /* @__PURE__ */ jsx("span", { className: "font-medium", children: "Video URL:" }),
          " ",
          lesson.videoUrl ? /* @__PURE__ */ jsx("a", { href: lesson.videoUrl, target: "_blank", rel: "noopener noreferrer", className: "text-blue-600 underline hover:text-blue-800", children: lesson.videoUrl }) : /* @__PURE__ */ jsx("span", { className: "text-muted-foreground italic", children: "No video attached" })
        ] })
      ] }) })
    ] }, lesson._id)) }),
    /* @__PURE__ */ jsx(Dialog, { open: isEditOpen, onOpenChange: setIsEditOpen, children: /* @__PURE__ */ jsxs(DialogContent, { autoFocus: false, children: [
      /* @__PURE__ */ jsx(DialogHeader, { children: /* @__PURE__ */ jsx(DialogTitle, { children: "Edit Lesson" }) }),
      editingLesson && /* @__PURE__ */ jsxs("form", { onSubmit: handleUpdate, children: [
        /* @__PURE__ */ jsxs("div", { className: "grid gap-4 py-4", children: [
          /* @__PURE__ */ jsxs("div", { className: "grid gap-2", children: [
            /* @__PURE__ */ jsx(Label, { htmlFor: "edit-lessonName", children: "Lesson Name" }),
            /* @__PURE__ */ jsx(Input, { id: "edit-lessonName", name: "lessonName", defaultValue: editingLesson.lessonName, required: true })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "grid gap-2", children: [
            /* @__PURE__ */ jsx(Label, { htmlFor: "edit-duration", children: "Duration" }),
            /* @__PURE__ */ jsx(Input, { id: "edit-duration", name: "duration", type: "number", required: true, defaultValue: editingLesson.duration, autoFocus: false })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "grid gap-2", children: [
            /* @__PURE__ */ jsx(Label, { htmlFor: "edit-order", children: "Order" }),
            /* @__PURE__ */ jsx(Input, { id: "edit-order", name: "order", type: "number", defaultValue: editingLesson.order, required: true, autoFocus: false })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "grid gap-2", children: [
            /* @__PURE__ */ jsx(Label, { htmlFor: "edit-videoUrl", children: "Video URL" }),
            /* @__PURE__ */ jsx(Input, { id: "edit-videoUrl", name: "videoUrl", defaultValue: editingLesson.videoUrl || "" })
          ] })
        ] }),
        /* @__PURE__ */ jsx(DialogFooter, { children: /* @__PURE__ */ jsx(Button, { type: "submit", disabled: updateMutation.isPending, children: "Save Changes" }) })
      ] })
    ] }) })
  ] });
}
export {
  RouteComponent as component
};
