import { jsx } from "react/jsx-runtime";
function RouteComponent() {
  return /* @__PURE__ */ jsx("div", { children: 'Hello "/"!' });
}
export {
  RouteComponent as component
};
