import { createRouter, createRootRoute, createFileRoute, lazyRouteComponent, Link, useLocation, HeadContent, Outlet, Scripts, useNavigate } from "@tanstack/react-router";
import { jsx, jsxs } from "react/jsx-runtime";
import { Slot } from "@radix-ui/react-slot";
import { cva } from "class-variance-authority";
import { clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { forwardRef, createElement, useState, useEffect } from "react";
import { useTheme } from "next-themes";
import { toast, Toaster as Toaster$1 } from "sonner";
import * as TooltipPrimitive from "@radix-ui/react-tooltip";
import { QueryClientProvider, QueryClient, useMutation } from "@tanstack/react-query";
import axios from "axios";
import * as LabelPrimitive from "@radix-ui/react-label";
const toKebabCase = (string) => string.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();
const toCamelCase = (string) => string.replace(
  /^([A-Z])|[\s-_]+(\w)/g,
  (match, p1, p2) => p2 ? p2.toUpperCase() : p1.toLowerCase()
);
const toPascalCase = (string) => {
  const camelCase = toCamelCase(string);
  return camelCase.charAt(0).toUpperCase() + camelCase.slice(1);
};
const mergeClasses = (...classes) => classes.filter((className, index, array) => {
  return Boolean(className) && className.trim() !== "" && array.indexOf(className) === index;
}).join(" ").trim();
const hasA11yProp = (props) => {
  for (const prop in props) {
    if (prop.startsWith("aria-") || prop === "role" || prop === "title") {
      return true;
    }
  }
};
var defaultAttributes = {
  xmlns: "http://www.w3.org/2000/svg",
  width: 24,
  height: 24,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2,
  strokeLinecap: "round",
  strokeLinejoin: "round"
};
const Icon = forwardRef(
  ({
    color = "currentColor",
    size = 24,
    strokeWidth = 2,
    absoluteStrokeWidth,
    className = "",
    children,
    iconNode,
    ...rest
  }, ref) => createElement(
    "svg",
    {
      ref,
      ...defaultAttributes,
      width: size,
      height: size,
      stroke: color,
      strokeWidth: absoluteStrokeWidth ? Number(strokeWidth) * 24 / Number(size) : strokeWidth,
      className: mergeClasses("lucide", className),
      ...!children && !hasA11yProp(rest) && { "aria-hidden": "true" },
      ...rest
    },
    [
      ...iconNode.map(([tag, attrs]) => createElement(tag, attrs)),
      ...Array.isArray(children) ? children : [children]
    ]
  )
);
const createLucideIcon = (iconName, iconNode) => {
  const Component = forwardRef(
    ({ className, ...props }, ref) => createElement(Icon, {
      ref,
      iconNode,
      className: mergeClasses(
        `lucide-${toKebabCase(toPascalCase(iconName))}`,
        `lucide-${iconName}`,
        className
      ),
      ...props
    })
  );
  Component.displayName = toPascalCase(iconName);
  return Component;
};
const __iconNode$f = [
  ["path", { d: "M12 7v14", key: "1akyts" }],
  [
    "path",
    {
      d: "M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z",
      key: "ruj8y"
    }
  ]
];
const BookOpen = createLucideIcon("book-open", __iconNode$f);
const __iconNode$e = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "m9 12 2 2 4-4", key: "dzmm74" }]
];
const CircleCheck = createLucideIcon("circle-check", __iconNode$e);
const __iconNode$d = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "m14 16-4-4 4-4", key: "ojs7w8" }]
];
const CircleChevronLeft = createLucideIcon("circle-chevron-left", __iconNode$d);
const __iconNode$c = [
  [
    "path",
    {
      d: "M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .696 10.747 10.747 0 0 1-1.444 2.49",
      key: "ct8e1f"
    }
  ],
  ["path", { d: "M14.084 14.158a3 3 0 0 1-4.242-4.242", key: "151rxh" }],
  [
    "path",
    {
      d: "M17.479 17.499a10.75 10.75 0 0 1-15.417-5.151 1 1 0 0 1 0-.696 10.75 10.75 0 0 1 4.446-5.143",
      key: "13bj9a"
    }
  ],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }]
];
const EyeOff = createLucideIcon("eye-off", __iconNode$c);
const __iconNode$b = [
  [
    "path",
    {
      d: "M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0",
      key: "1nclc0"
    }
  ],
  ["circle", { cx: "12", cy: "12", r: "3", key: "1v7zrd" }]
];
const Eye = createLucideIcon("eye", __iconNode$b);
const __iconNode$a = [
  ["path", { d: "M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8", key: "5wwlr5" }],
  [
    "path",
    {
      d: "M3 10a2 2 0 0 1 .709-1.528l7-6a2 2 0 0 1 2.582 0l7 6A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",
      key: "r6nss1"
    }
  ]
];
const House = createLucideIcon("house", __iconNode$a);
const __iconNode$9 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M12 16v-4", key: "1dtifu" }],
  ["path", { d: "M12 8h.01", key: "e9boi3" }]
];
const Info = createLucideIcon("info", __iconNode$9);
const __iconNode$8 = [
  ["path", { d: "m16 6 4 14", key: "ji33uf" }],
  ["path", { d: "M12 6v14", key: "1n7gus" }],
  ["path", { d: "M8 8v12", key: "1gg7y9" }],
  ["path", { d: "M4 4v16", key: "6qkkli" }]
];
const Library = createLucideIcon("library", __iconNode$8);
const __iconNode$7 = [["path", { d: "M21 12a9 9 0 1 1-6.219-8.56", key: "13zald" }]];
const LoaderCircle = createLucideIcon("loader-circle", __iconNode$7);
const __iconNode$6 = [
  ["path", { d: "M4 5h16", key: "1tepv9" }],
  ["path", { d: "M4 12h16", key: "1lakjw" }],
  ["path", { d: "M4 19h16", key: "1djgab" }]
];
const Menu = createLucideIcon("menu", __iconNode$6);
const __iconNode$5 = [
  [
    "path",
    {
      d: "M2.992 16.342a2 2 0 0 1 .094 1.167l-1.065 3.29a1 1 0 0 0 1.236 1.168l3.413-.998a2 2 0 0 1 1.099.092 10 10 0 1 0-4.777-4.719",
      key: "1sd12s"
    }
  ],
  ["path", { d: "M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3", key: "1u773s" }],
  ["path", { d: "M12 17h.01", key: "p32p05" }]
];
const MessageCircleQuestionMark = createLucideIcon("message-circle-question-mark", __iconNode$5);
const __iconNode$4 = [
  [
    "path",
    {
      d: "M20.985 12.486a9 9 0 1 1-9.473-9.472c.405-.022.617.46.402.803a6 6 0 0 0 8.268 8.268c.344-.215.825-.004.803.401",
      key: "kfwtm"
    }
  ]
];
const Moon = createLucideIcon("moon", __iconNode$4);
const __iconNode$3 = [
  ["path", { d: "m15 9-6 6", key: "1uzhvr" }],
  [
    "path",
    {
      d: "M2.586 16.726A2 2 0 0 1 2 15.312V8.688a2 2 0 0 1 .586-1.414l4.688-4.688A2 2 0 0 1 8.688 2h6.624a2 2 0 0 1 1.414.586l4.688 4.688A2 2 0 0 1 22 8.688v6.624a2 2 0 0 1-.586 1.414l-4.688 4.688a2 2 0 0 1-1.414.586H8.688a2 2 0 0 1-1.414-.586z",
      key: "2d38gg"
    }
  ],
  ["path", { d: "m9 9 6 6", key: "z0biqf" }]
];
const OctagonX = createLucideIcon("octagon-x", __iconNode$3);
const __iconNode$2 = [
  ["circle", { cx: "12", cy: "12", r: "4", key: "4exip2" }],
  ["path", { d: "M12 2v2", key: "tus03m" }],
  ["path", { d: "M12 20v2", key: "1lh1kg" }],
  ["path", { d: "m4.93 4.93 1.41 1.41", key: "149t6j" }],
  ["path", { d: "m17.66 17.66 1.41 1.41", key: "ptbguv" }],
  ["path", { d: "M2 12h2", key: "1t8f8n" }],
  ["path", { d: "M20 12h2", key: "1q8mjw" }],
  ["path", { d: "m6.34 17.66-1.41 1.41", key: "1m8zz5" }],
  ["path", { d: "m19.07 4.93-1.41 1.41", key: "1shlcs" }]
];
const Sun = createLucideIcon("sun", __iconNode$2);
const __iconNode$1 = [
  [
    "path",
    {
      d: "m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",
      key: "wmoenq"
    }
  ],
  ["path", { d: "M12 9v4", key: "juzpu7" }],
  ["path", { d: "M12 17h.01", key: "p32p05" }]
];
const TriangleAlert = createLucideIcon("triangle-alert", __iconNode$1);
const __iconNode = [
  ["path", { d: "M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2", key: "975kel" }],
  ["circle", { cx: "12", cy: "7", r: "4", key: "17ys0d" }]
];
const User = createLucideIcon("user", __iconNode);
const appCss = "/assets/styles-D2223sKW.css";
function cn(...inputs) {
  return twMerge(clsx(inputs));
}
const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-all disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px] aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground hover:bg-primary/90",
        destructive: "bg-destructive text-white hover:bg-destructive/90 focus-visible:ring-destructive/20 dark:focus-visible:ring-destructive/40 dark:bg-destructive/60",
        outline: "border bg-background shadow-xs hover:bg-accent hover:text-accent-foreground dark:bg-input/30 dark:border-input dark:hover:bg-input/50",
        secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
        ghost: "hover:bg-accent hover:text-accent-foreground dark:hover:bg-accent/50",
        link: "text-primary underline-offset-4 hover:underline"
      },
      size: {
        default: "h-9 px-4 py-2 has-[>svg]:px-3",
        sm: "h-8 rounded-md gap-1.5 px-3 has-[>svg]:px-2.5",
        lg: "h-10 rounded-md px-6 has-[>svg]:px-4",
        icon: "size-9",
        "icon-sm": "size-8",
        "icon-lg": "size-10"
      }
    },
    defaultVariants: {
      variant: "default",
      size: "default"
    }
  }
);
function Button({
  className,
  variant = "default",
  size = "default",
  asChild = false,
  ...props
}) {
  const Comp = asChild ? Slot : "button";
  return /* @__PURE__ */ jsx(
    Comp,
    {
      "data-slot": "button",
      "data-variant": variant,
      "data-size": size,
      className: cn(buttonVariants({ variant, size, className })),
      ...props
    }
  );
}
function NotFound() {
  return /* @__PURE__ */ jsx("div", { className: "min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center p-5", children: /* @__PURE__ */ jsxs("div", { className: "text-center space-y-8", children: [
    /* @__PURE__ */ jsx("h1", { className: "text-9xl font-black text-white/20 select-none", children: "404" }),
    /* @__PURE__ */ jsxs("div", { className: "space-y-4", children: [
      /* @__PURE__ */ jsx("p", { className: "text-4xl font-bold text-white", children: "Page Not Found" }),
      /* @__PURE__ */ jsx("p", { className: "text-xl text-purple-200 max-w-md mx-auto", children: "The course or lesson you're looking for doesn't exist... yet!" })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex gap-4 justify-center", children: [
      /* @__PURE__ */ jsx(Button, { asChild: true, size: "lg", className: "bg-purple-600 hover:bg-purple-700", children: /* @__PURE__ */ jsxs(Link, { to: "/demo/api/names", children: [
        /* @__PURE__ */ jsx(BookOpen, { className: "mr-2 h-5 w-5" }),
        "Browse Courses"
      ] }) }),
      /* @__PURE__ */ jsx(Button, { asChild: true, variant: "outline", size: "lg", children: /* @__PURE__ */ jsxs(Link, { to: "/", className: "text-white border-purple-400 hover:bg-purple-600", children: [
        /* @__PURE__ */ jsx(House, { className: "mr-2 h-5 w-5" }),
        "Home"
      ] }) })
    ] })
  ] }) });
}
const Toaster = ({ ...props }) => {
  const { theme = "system" } = useTheme();
  return /* @__PURE__ */ jsx(
    Toaster$1,
    {
      theme,
      className: "toaster group",
      icons: {
        success: /* @__PURE__ */ jsx(CircleCheck, { className: "size-4" }),
        info: /* @__PURE__ */ jsx(Info, { className: "size-4" }),
        warning: /* @__PURE__ */ jsx(TriangleAlert, { className: "size-4" }),
        error: /* @__PURE__ */ jsx(OctagonX, { className: "size-4" }),
        loading: /* @__PURE__ */ jsx(LoaderCircle, { className: "size-4 animate-spin" })
      },
      style: {
        "--normal-bg": "var(--popover)",
        "--normal-text": "var(--popover-foreground)",
        "--normal-border": "var(--border)",
        "--border-radius": "var(--radius)"
      },
      ...props
    }
  );
};
function TooltipProvider({
  delayDuration = 0,
  ...props
}) {
  return /* @__PURE__ */ jsx(
    TooltipPrimitive.Provider,
    {
      "data-slot": "tooltip-provider",
      delayDuration,
      ...props
    }
  );
}
function Tooltip({
  ...props
}) {
  return /* @__PURE__ */ jsx(TooltipProvider, { children: /* @__PURE__ */ jsx(TooltipPrimitive.Root, { "data-slot": "tooltip", ...props }) });
}
function TooltipTrigger({
  ...props
}) {
  return /* @__PURE__ */ jsx(TooltipPrimitive.Trigger, { "data-slot": "tooltip-trigger", ...props });
}
function TooltipContent({
  className,
  sideOffset = 0,
  children,
  ...props
}) {
  return /* @__PURE__ */ jsx(TooltipPrimitive.Portal, { children: /* @__PURE__ */ jsxs(
    TooltipPrimitive.Content,
    {
      "data-slot": "tooltip-content",
      sideOffset,
      className: cn(
        "bg-foreground text-background animate-in fade-in-0 zoom-in-95 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 z-50 w-fit origin-(--radix-tooltip-content-transform-origin) rounded-md px-3 py-1.5 text-xs text-balance",
        className
      ),
      ...props,
      children: [
        children,
        /* @__PURE__ */ jsx(TooltipPrimitive.Arrow, { className: "bg-foreground fill-foreground z-50 size-2.5 translate-y-[calc(-50%_-_2px)] rotate-45 rounded-[2px]" })
      ]
    }
  ) });
}
const links = [
  { name: "Dashboard", href: "/", icon: House },
  { name: "Courses", href: "/courses", icon: Library },
  { name: "Mentors", href: "/mentors", icon: User },
  {
    name: "Questions",
    href: "/questions?lessonId=694b64159a673d7d1b495b1c&courseId=694b63969a673d7d1b495b19&chapterId=694b63e79a673d7d1b495b1a&mode=create",
    icon: MessageCircleQuestionMark
  }
];
function Layout({ isDarkMode, setIsDarkMode }) {
  const navigate = useNavigate();
  const location = useLocation();
  const [isIconMode, setIsIconMode] = useState(true);
  const [activeMenu, setActiveMenu] = useState("");
  const [isOpen, setIsOpen] = useState(false);
  const [isLargeScreen, setIsLargeScreen] = useState(true);
  const [mounted, setMounted] = useState(false);
  useEffect(() => {
    setMounted(true);
    const savedSidebarMode = localStorage.getItem("sidebarMode");
    if (savedSidebarMode === "icon") {
      setIsIconMode(true);
    } else {
      setIsIconMode(false);
    }
    const savedDarkMode = localStorage.getItem("darkMode");
    if (savedDarkMode === "true") {
      setIsDarkMode(true);
    }
    setIsLargeScreen(window.innerWidth >= 1024);
  }, []);
  const toggleDarkMode = () => {
    const newDarkMode = !isDarkMode;
    setIsDarkMode(newDarkMode);
    localStorage.setItem("darkMode", String(newDarkMode));
  };
  useEffect(() => {
    const handleResize = () => {
      setIsLargeScreen(window.innerWidth >= 1024);
    };
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);
  useEffect(() => {
    if (mounted && isLargeScreen) {
      localStorage.setItem("sidebarMode", isIconMode ? "icon" : "default");
    }
  }, [isIconMode, isLargeScreen, mounted]);
  const toggleSidebar = () => {
    if (isLargeScreen) {
      setIsIconMode(!isIconMode);
    } else {
      setIsOpen(!isOpen);
    }
  };
  const handleMenuClick = (path) => {
    navigate({
      to: path
    });
    setActiveMenu(path);
    setIsOpen(false);
  };
  useEffect(() => {
    const activeMenu2 = location.pathname.split("/")[1] ? `/${location.pathname.split("/")[1]}` : "/";
    setActiveMenu(activeMenu2);
  }, [location.pathname]);
  return /* @__PURE__ */ jsxs("main", { children: [
    /* @__PURE__ */ jsx(
      "aside",
      {
        className: `z-50
          min-h-screen bg-sidebar text-sidebar-foreground transform fixed transition-all duration-300
          overflow-hidden
          ${isLargeScreen ? isIconMode ? "w-20" : "w-72" : isOpen ? "w-72 opacity-100 pointer-events-auto" : "w-0 p-0 pointer-events-none -translate-x-72 duration-500"}
        `,
        children: /* @__PURE__ */ jsxs("ul", { className: "flex flex-col gap-0 relative", children: [
          /* @__PURE__ */ jsxs(
            "li",
            {
              className: `flex items-center absolute top-2 right-0 p-2 m-1 gap-3 rounded-sm cursor-pointer ${isIconMode && isLargeScreen ? "justify-center" : ""}`,
              children: [
                !isLargeScreen && /* @__PURE__ */ jsx(
                  CircleChevronLeft,
                  {
                    className: "right-2 cursor-pointer",
                    onClick: toggleSidebar
                  }
                ),
                isLargeScreen && !isIconMode && /* @__PURE__ */ jsx(
                  CircleChevronLeft,
                  {
                    className: "right-2 cursor-pointer",
                    onClick: toggleSidebar
                  }
                )
              ]
            }
          ),
          /* @__PURE__ */ jsx(
            "li",
            {
              className: `flex items-center p-2 m-1 gap-3 rounded-sm min-h-16 cursor-pointer ${isIconMode && isLargeScreen ? "justify-center" : ""}`,
              children: /* @__PURE__ */ jsxs("span", { children: [
                !isIconMode && /* @__PURE__ */ jsx("img", { src: "/logo.png", alt: "", className: "" }),
                isIconMode && isLargeScreen && /* @__PURE__ */ jsx(
                  Menu,
                  {
                    className: `cursor-pointer ${isIconMode ? "top-12 right-0" : ""}`,
                    onClick: toggleSidebar
                  }
                )
              ] })
            }
          ),
          links.map(
            (link, index) => isIconMode ? /* @__PURE__ */ jsxs(Tooltip, { children: [
              /* @__PURE__ */ jsx(TooltipTrigger, { asChild: true, children: /* @__PURE__ */ jsxs(
                "li",
                {
                  onClick: () => handleMenuClick(link.href),
                  className: `flex items-center p-2 m-1 gap-3 rounded-sm cursor-pointer hover:bg-background hover:text-sidebar-foreground ${isIconMode && isLargeScreen ? "justify-center" : ""} ${activeMenu === link.href ? "bg-background text-sidebar-foreground" : ""}`,
                  children: [
                    /* @__PURE__ */ jsx("span", { children: /* @__PURE__ */ jsx(link.icon, { className: "w-6 h-6" }) }),
                    (!isLargeScreen && isOpen || isLargeScreen && !isIconMode) && /* @__PURE__ */ jsx("span", { className: "text-lg", children: link.name })
                  ]
                }
              ) }),
              /* @__PURE__ */ jsx(TooltipContent, { side: "right", children: /* @__PURE__ */ jsx("p", { children: link.name }) })
            ] }, index) : /* @__PURE__ */ jsxs(
              "li",
              {
                onClick: () => handleMenuClick(link.href),
                className: `flex items-center p-2 m-1 gap-3 rounded-sm cursor-pointer hover:bg-background hover:text-sidebar-foreground ${isIconMode && isLargeScreen ? "justify-center" : ""} ${activeMenu === link.href ? "bg-background text-sidebar-foreground" : ""}`,
                children: [
                  /* @__PURE__ */ jsx("span", { children: /* @__PURE__ */ jsx(link.icon, { className: "w-6 h-6" }) }),
                  (!isLargeScreen && isOpen || isLargeScreen && !isIconMode) && /* @__PURE__ */ jsx("span", { className: "text-lg", children: link.name })
                ]
              },
              index
            )
          )
        ] })
      }
    ),
    /* @__PURE__ */ jsxs(
      "header",
      {
        className: `h-16 z-45 fixed flex justify-between transform transition-all duration-300 bg-sidebar text-sidebar-foreground p-2 ${isLargeScreen && !isIconMode ? "ml-72 min-w-[calc(100vw-18rem)]" : isLargeScreen ? "ml-20 min-w-[calc(100vw-5rem)]" : "min-w-full"}`,
        children: [
          /* @__PURE__ */ jsxs("div", { className: "h-full flex items-center text-primary gap-3", children: [
            !isLargeScreen && /* @__PURE__ */ jsx(Menu, { className: "cursor-pointer", onClick: toggleSidebar }),
            /* @__PURE__ */ jsx("h1", { className: "text-3xl capitalize text-foreground", children: location.pathname.split("/")[1] !== "" ? location.pathname.split("/")[1] : "Dashboard" })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "h-full flex items-center mr-5", children: /* @__PURE__ */ jsx("button", { onClick: toggleDarkMode, children: isDarkMode ? /* @__PURE__ */ jsx(Sun, { className: "w-6 h-6" }) : /* @__PURE__ */ jsx(Moon, { className: "w-6 h-6" }) }) })
        ]
      }
    ),
    /* @__PURE__ */ jsxs(
      "main",
      {
        className: `relative p-2 pt-18 ${isLargeScreen && !isIconMode ? "ml-72" : isLargeScreen ? "ml-20" : ""}`,
        children: [
          /* @__PURE__ */ jsx(Outlet, {}),
          /* @__PURE__ */ jsx(Toaster, {})
        ]
      }
    )
  ] });
}
const BACKEND_BASE_URL = "http://13.201.119.4/api";
const Config = {
  baseUrl: BACKEND_BASE_URL
};
const _axios = axios.create({
  baseURL: Config.baseUrl,
  withCredentials: true
});
if (typeof window !== "undefined") {
  _axios.interceptors.request.use((config) => {
    return config;
  });
  _axios.interceptors.response.use(
    (response) => response,
    (error) => {
      if (error.response) {
        if (error.response.status === 401) {
          if (window) {
            localStorage.clear();
          }
          return Promise.reject(
            new Error("Unauthorized")
          );
        }
        if (error.response.status >= 500) {
          return Promise.reject(
            new Error(
              "Server error, please try again later.",
              error.response.data
            )
          );
        }
        return Promise.reject(
          error.response.data || new Error("An error occurred")
        );
      } else if (error.request) {
        return Promise.reject(
          new Error("No response from server, check your network.")
        );
      } else {
        return Promise.reject(new Error("Request failed, please try again."));
      }
    }
  );
}
const Route$9 = createRootRoute({
  head: () => ({
    meta: [
      {
        charSet: "utf-8"
      },
      {
        name: "viewport",
        content: "width=device-width, initial-scale=1"
      },
      {
        name: "description",
        content: "Ideal Admin - Modern admin dashboard for managing your applications"
      },
      {
        name: "keywords",
        content: "admin, dashboard, management, panel, analytics"
      },
      {
        name: "author",
        content: "Ideal Admin"
      },
      {
        name: "theme-color",
        content: "#3b82f6"
      },
      // Open Graph / Facebook
      {
        property: "og:type",
        content: "website"
      },
      {
        property: "og:title",
        content: "Ideal Admin - Modern Admin Dashboard"
      },
      {
        property: "og:description",
        content: "Powerful and intuitive admin dashboard for managing your applications"
      },
      {
        property: "og:image",
        content: "/og-image.jpg"
        // Add your OG image path
      },
      // Twitter
      {
        name: "twitter:card",
        content: "summary_large_image"
      },
      {
        name: "twitter:title",
        content: "Ideal Admin - Modern Admin Dashboard"
      },
      {
        name: "twitter:description",
        content: "Powerful and intuitive admin dashboard for managing your applications"
      },
      {
        name: "twitter:image",
        content: "/twitter-image.jpg"
        // Add your Twitter image path
      }
    ],
    title: "Ideal Admin - Modern Admin Dashboard",
    links: [
      {
        rel: "stylesheet",
        href: appCss
      },
      // Favicon and Apple Touch Icons
      {
        rel: "icon",
        type: "image/x-icon",
        href: "/favicon.ico"
      },
      {
        rel: "icon",
        type: "image/png",
        sizes: "32x32",
        href: "/favicon-32x32.png"
      },
      {
        rel: "icon",
        type: "image/png",
        sizes: "16x16",
        href: "/favicon-16x16.png"
      },
      {
        rel: "apple-touch-icon",
        sizes: "180x180",
        href: "/apple-touch-icon.png"
      },
      {
        rel: "manifest",
        href: "/site.webmanifest"
      }
    ]
  }),
  shellComponent: RootDocument,
  notFoundComponent: NotFound
});
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1e3 * 60
    }
  }
});
function RootDocument() {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = Route$9.useNavigate();
  const location = useLocation();
  const authRoutes = ["/login"];
  const isAuthRoute = authRoutes.includes(location.pathname);
  useEffect(() => {
    const fetchSession = async () => {
      try {
        const res = await _axios.get("/admin-auth/session");
        console.log(res.data);
        setSession(res.data.data);
      } catch (err) {
        setSession(null);
      } finally {
        setLoading(false);
      }
    };
    fetchSession();
  }, [location.pathname]);
  useEffect(() => {
    console.log(session, isAuthRoute, loading);
    if (!loading && !session && !isAuthRoute) {
      navigate({ to: "/login" });
    }
    if (!loading && session && isAuthRoute) {
      navigate({ to: "/" });
    }
  }, [loading, session, isAuthRoute]);
  return /* @__PURE__ */ jsxs("html", { lang: "en", children: [
    /* @__PURE__ */ jsxs("head", { children: [
      /* @__PURE__ */ jsx("title", { children: "Ideal Admin" }),
      /* @__PURE__ */ jsx(HeadContent, {})
    ] }),
    /* @__PURE__ */ jsxs("body", { className: `${isDarkMode ? "dark" : ""}`, children: [
      /* @__PURE__ */ jsx(QueryClientProvider, { client: queryClient, children: location.pathname === "/login" ? /* @__PURE__ */ jsx(Outlet, {}) : /* @__PURE__ */ jsx(Layout, { isDarkMode, setIsDarkMode }) }),
      /* @__PURE__ */ jsx(Scripts, {})
    ] })
  ] });
}
function Label({
  className,
  ...props
}) {
  return /* @__PURE__ */ jsx(
    LabelPrimitive.Root,
    {
      "data-slot": "label",
      className: cn(
        "flex items-center gap-2 text-sm leading-none font-medium select-none group-data-[disabled=true]:pointer-events-none group-data-[disabled=true]:opacity-50 peer-disabled:cursor-not-allowed peer-disabled:opacity-50",
        className
      ),
      ...props
    }
  );
}
const Route$8 = createFileRoute("/login")({
  component: LoginPage
});
function LoginPage() {
  const navigate = Route$8.useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [errors, setErrors] = useState({});
  const loginMutation = useMutation({
    mutationFn: async () => {
      const res = await _axios.post("/admin-auth/login", { email, password });
      return res.data;
    },
    onSuccess: (data) => {
      toast.success("Login successfully");
      navigate({ to: "/" });
      console.log("Login success:", data);
      setErrors({});
    },
    onError: (error) => {
      console.error("Login error:", error);
      const msg = error?.response?.data?.message || error?.message || "Invalid email or password. Please try again.";
      setErrors((prev) => ({ ...prev, root: msg }));
    }
  });
  const validate = () => {
    const newErrors = {};
    if (!email) newErrors.email = "Email is required";
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
      newErrors.email = "Please enter a valid email address";
    if (!password) newErrors.password = "Password is required";
    else if (password.length < 3)
      newErrors.password = "Password must be at least 6 characters";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    setErrors((prev) => ({ ...prev, root: void 0 }));
    if (!validate()) return;
    loginMutation.mutate();
  };
  const handleBlur = (field) => {
    const temp = { ...errors };
    delete temp.root;
    if (field === "email") {
      if (!email) temp.email = "Email is required";
      else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
        temp.email = "Please enter a valid email address";
      else delete temp.email;
    }
    if (field === "password") {
      if (!password) temp.password = "Password is required";
      else if (password.length < 3)
        temp.password = "Password must be at least 6 characters";
      else delete temp.password;
    }
    setErrors(temp);
  };
  return /* @__PURE__ */ jsxs("div", { className: "min-h-screen flex flex-col lg:flex-row", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex-1 lg:w-1/2 flex flex-col justify-center px-6 py-12 lg:px-8 bg-background", children: [
      /* @__PURE__ */ jsxs("div", { className: "sm:mx-auto sm:w-full sm:max-w-md", children: [
        /* @__PURE__ */ jsx("div", { className: "flex justify-center", children: /* @__PURE__ */ jsx("img", { src: "/logo.png", alt: "Logo", className: "h-12 w-auto" }) }),
        /* @__PURE__ */ jsx("h2", { className: "mt-8 text-center text-3xl font-bold tracking-tight text-foreground", children: "Welcome back" }),
        /* @__PURE__ */ jsx("p", { className: "mt-2 text-center text-sm text-muted-foreground", children: "Please enter your details" })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "mt-10 sm:mx-auto sm:w-full sm:max-w-md", children: /* @__PURE__ */ jsxs("form", { className: "space-y-6", onSubmit: handleSubmit, children: [
        /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx(Label, { htmlFor: "email", children: "Email address" }),
          /* @__PURE__ */ jsxs("div", { className: "relative", children: [
            /* @__PURE__ */ jsx(
              "input",
              {
                id: "email",
                type: "email",
                autoComplete: "email",
                required: true,
                value: email,
                onChange: (e) => setEmail(e.target.value),
                onBlur: () => handleBlur("email"),
                placeholder: "you@example.com",
                className: `
                    block w-full h-12 px-0 py-2
                    bg-transparent text-foreground placeholder:text-muted-foreground
                    border-0 border-b-2 
                    ${errors.email ? "border-destructive" : "border-primary/30"}
                    focus:border-primary focus:outline-none
                    transition-colors duration-200 caret-primary
                  `
              }
            ),
            /* @__PURE__ */ jsx(
              "span",
              {
                className: `
                    absolute left-0 bottom-0 h-0.5 bg-primary
                    transition-transform duration-300 origin-left
                    ${email ? "scale-x-100" : "scale-x-0"}
                  `
              }
            )
          ] }),
          errors.email && /* @__PURE__ */ jsx("p", { className: "text-sm text-destructive", children: errors.email })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsx(Label, { htmlFor: "password", children: "Password" }),
          /* @__PURE__ */ jsxs("div", { className: "relative", children: [
            /* @__PURE__ */ jsx(
              "input",
              {
                id: "password",
                type: showPassword ? "text" : "password",
                autoComplete: "current-password",
                required: true,
                value: password,
                onChange: (e) => setPassword(e.target.value),
                onBlur: () => handleBlur("password"),
                placeholder: "••••••••",
                className: `
                    block w-full h-12 px-0 py-2 pr-10
                    bg-transparent text-foreground placeholder:text-muted-foreground
                    border-0 border-b-2 
                    ${errors.password ? "border-destructive" : "border-primary/30"}
                    focus:border-primary focus:outline-none
                    transition-colors duration-200 caret-primary
                  `
              }
            ),
            /* @__PURE__ */ jsx(
              "span",
              {
                className: `
                    absolute left-0 bottom-0 h-0.5 bg-primary
                    transition-transform duration-300 origin-left
                    ${password ? "scale-x-100" : "scale-x-0"}
                  `
              }
            ),
            /* @__PURE__ */ jsx(
              "button",
              {
                type: "button",
                onClick: () => setShowPassword(!showPassword),
                className: "absolute right-0 top-1/2 -translate-y-1/2 p-2 text-muted-foreground hover:text-foreground transition-colors",
                "aria-label": showPassword ? "Hide password" : "Show password",
                children: showPassword ? /* @__PURE__ */ jsx(EyeOff, { className: "h-5 w-5 cursor-pointer" }) : /* @__PURE__ */ jsx(Eye, { className: "h-5 w-5 cursor-pointer" })
              }
            )
          ] }),
          errors.password && /* @__PURE__ */ jsx("p", { className: "text-sm text-destructive", children: errors.password })
        ] }),
        errors.root && /* @__PURE__ */ jsx("div", { className: "p-3 rounded-md bg-destructive/10 border border-destructive text-destructive text-sm", children: errors.root }),
        /* @__PURE__ */ jsx(
          Button,
          {
            type: "submit",
            className: "w-full h-12 bg-foreground text-background hover:bg-foreground/90 cursor-pointer rounded-[4px]",
            disabled: loginMutation.isPending,
            children: loginMutation.isPending ? /* @__PURE__ */ jsxs("svg", { className: "animate-spin h-5 w-5", viewBox: "0 0 24 24", children: [
              /* @__PURE__ */ jsx(
                "circle",
                {
                  className: "opacity-25",
                  cx: "12",
                  cy: "12",
                  r: "10",
                  stroke: "currentColor",
                  strokeWidth: "4",
                  fill: "none"
                }
              ),
              /* @__PURE__ */ jsx(
                "path",
                {
                  className: "opacity-75",
                  fill: "currentColor",
                  d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                }
              )
            ] }) : "Sign in"
          }
        )
      ] }) })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "hidden lg:flex lg:w-1/2 relative overflow-hidden", children: [
      /* @__PURE__ */ jsx(
        "div",
        {
          className: "absolute inset-0 bg-primary",
          style: {
            clipPath: "polygon(20% 0%, 100% 0%, 100% 100%, 0% 100%)"
          }
        }
      ),
      /* @__PURE__ */ jsx(
        "div",
        {
          className: "absolute inset-0 bg-gradient-to-r from-primary/80 to-primary/100",
          style: {
            clipPath: "polygon(20% 0%, 100% 0%, 100% 100%, 0% 100%)"
          }
        }
      ),
      /* @__PURE__ */ jsxs("div", { className: "relative z-10 flex flex-col justify-center items-center p-12 text-background h-full w-full text-center", children: [
        /* @__PURE__ */ jsx("h1", { className: "text-4xl font-bold tracking-tight", children: "Bring your ideas to life." }),
        /* @__PURE__ */ jsx("p", { className: "mt-3 text-lg max-w-md", children: "Sign up for free." })
      ] })
    ] })
  ] });
}
const $$splitComponentImporter$7 = () => import("./index-BN6JQF57.mjs");
const Route$7 = createFileRoute("/")({
  component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
const $$splitComponentImporter$6 = () => import("./index-DupXJTPA.mjs");
const Route$6 = createFileRoute("/questions/")({
  component: lazyRouteComponent($$splitComponentImporter$6, "component"),
  validateSearch: (search) => search
});
const $$splitComponentImporter$5 = () => import("./index-K86GKIfz.mjs");
const Route$5 = createFileRoute("/mentors/")({
  component: lazyRouteComponent($$splitComponentImporter$5, "component"),
  validateSearch: (search) => {
    return {
      page: Number(search.page ?? 1),
      search: search.search ?? "",
      sortBy: search.sortBy ?? "createdAt",
      sortOrder: search.sortOrder ?? "desc"
    };
  }
});
const $$splitComponentImporter$4 = () => import("./index-2E125KKQ.mjs");
const Route$4 = createFileRoute("/courses/")({
  component: lazyRouteComponent($$splitComponentImporter$4, "component"),
  validateSearch: (search) => {
    return {
      page: Number(search.page ?? 1),
      search: search.search ?? "",
      sortBy: search.sortBy ?? "createdAt",
      sortOrder: search.sortOrder ?? "desc"
    };
  }
});
const $$splitComponentImporter$3 = () => import("./_id-BebJ0Ch1.mjs");
const Route$3 = createFileRoute("/mentors/$id")({
  component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
const $$splitComponentImporter$2 = () => import("./index-Dx1juF3d.mjs");
const Route$2 = createFileRoute("/courses/$id/")({
  component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
const $$splitComponentImporter$1 = () => import("./route-B6nAqEq8.mjs");
const Route$1 = createFileRoute("/courses/$id/chapters")({
  component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
const $$splitComponentImporter = () => import("./index-akE2p71K.mjs");
const Route = createFileRoute("/courses/$id/chapters/$chapterId/")({
  component: lazyRouteComponent($$splitComponentImporter, "component")
});
const LoginRoute = Route$8.update({
  id: "/login",
  path: "/login",
  getParentRoute: () => Route$9
});
const IndexRoute = Route$7.update({
  id: "/",
  path: "/",
  getParentRoute: () => Route$9
});
const QuestionsIndexRoute = Route$6.update({
  id: "/questions/",
  path: "/questions/",
  getParentRoute: () => Route$9
});
const MentorsIndexRoute = Route$5.update({
  id: "/mentors/",
  path: "/mentors/",
  getParentRoute: () => Route$9
});
const CoursesIndexRoute = Route$4.update({
  id: "/courses/",
  path: "/courses/",
  getParentRoute: () => Route$9
});
const MentorsIdRoute = Route$3.update({
  id: "/mentors/$id",
  path: "/mentors/$id",
  getParentRoute: () => Route$9
});
const CoursesIdIndexRoute = Route$2.update({
  id: "/courses/$id/",
  path: "/courses/$id/",
  getParentRoute: () => Route$9
});
const CoursesIdChaptersRouteRoute = Route$1.update({
  id: "/courses/$id/chapters",
  path: "/courses/$id/chapters",
  getParentRoute: () => Route$9
});
const CoursesIdChaptersChapterIdIndexRoute = Route.update({
  id: "/$chapterId/",
  path: "/$chapterId/",
  getParentRoute: () => CoursesIdChaptersRouteRoute
});
const CoursesIdChaptersRouteRouteChildren = {
  CoursesIdChaptersChapterIdIndexRoute
};
const CoursesIdChaptersRouteRouteWithChildren = CoursesIdChaptersRouteRoute._addFileChildren(
  CoursesIdChaptersRouteRouteChildren
);
const rootRouteChildren = {
  IndexRoute,
  LoginRoute,
  MentorsIdRoute,
  CoursesIndexRoute,
  MentorsIndexRoute,
  QuestionsIndexRoute,
  CoursesIdChaptersRouteRoute: CoursesIdChaptersRouteRouteWithChildren,
  CoursesIdIndexRoute
};
const routeTree = Route$9._addFileChildren(rootRouteChildren)._addFileTypes();
const getRouter = () => {
  const router2 = createRouter({
    routeTree,
    scrollRestoration: true,
    defaultPreloadStaleTime: 0
  });
  return router2;
};
const router = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  getRouter
}, Symbol.toStringTag, { value: "Module" }));
const routerNT5qfVO = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  B: Button,
  L: Label,
  N: NotFound,
  R: Route$5,
  _: _axios,
  a: Route$4,
  b: Route$3,
  c: cn,
  d: Route$2,
  e: Route$1,
  f: Route,
  g: buttonVariants,
  r: router
});
export {
  Button as B,
  Eye as E,
  Label as L,
  NotFound as N,
  Route$5 as R,
  _axios as _,
  Route$4 as a,
  cn as b,
  createLucideIcon as c,
  Route$3 as d,
  LoaderCircle as e,
  Route$2 as f,
  Route$1 as g,
  Route as h,
  buttonVariants as i,
  routerNT5qfVO as r
};
