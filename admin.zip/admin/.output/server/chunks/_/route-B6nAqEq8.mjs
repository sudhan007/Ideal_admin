import { jsx, Fragment, jsxs } from "react/jsx-runtime";
import { useNavigate, Outlet } from "@tanstack/react-router";
import { useQueryClient, useQuery, useMutation } from "@tanstack/react-query";
import { g as Route$1, h as Route, _ as _axios, B as Button, L as Label, b as cn } from "./router-nT5qf-VO.mjs";
import { D as Dialog, a as DialogTrigger, b as DialogContent, c as DialogHeader, d as DialogTitle, e as DialogDescription, f as DialogFooter, g as DialogClose } from "./dialog-BnYcus8l.mjs";
import { I as Input } from "./input-B5eCZYSF.mjs";
import { useState } from "react";
import { toast } from "sonner";
import { A as ArrowBigLeft } from "./arrow-big-left.mjs";
import { P as Plus } from "./plus.mjs";
import { P as Pencil } from "./pencil.mjs";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "next-themes";
import "@radix-ui/react-tooltip";
import "axios";
import "@radix-ui/react-label";
import "@radix-ui/react-dialog";
function Textarea({ className, ...props }) {
  return /* @__PURE__ */ jsx(
    "textarea",
    {
      "data-slot": "textarea",
      className: cn(
        "border-input placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-ring/50 aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive dark:bg-input/30 flex field-sizing-content min-h-16 w-full rounded-md border bg-transparent px-3 py-2 text-base shadow-xs transition-[color,box-shadow] outline-none focus-visible:ring-[3px] disabled:cursor-not-allowed disabled:opacity-50 md:text-sm",
        className
      ),
      ...props
    }
  );
}
function ChaptersPage() {
  const {
    id: courseId
  } = Route$1.useParams();
  const {
    chapterId
  } = Route?.useParams();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingChapter, setEditingChapter] = useState(null);
  const [formData, setFormData] = useState({
    chapterName: "",
    chapterDescription: "",
    order: void 0
  });
  const {
    data: chapters = [],
    isLoading: chaptersLoading
  } = useQuery({
    queryKey: ["chapters", courseId],
    queryFn: async () => {
      const res = await _axios.get(`/chapters/${courseId}`);
      const chaptersData = res.data.chapters || res.data;
      return chaptersData;
    }
  });
  const createMutation = useMutation({
    mutationFn: async (data) => {
      const res = await _axios.post("/chapters", {
        courseId,
        chapterName: data.chapterName,
        chapterDescription: data.chapterDescription,
        order: data.order
      });
      return res.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["chapters", courseId]
      });
      setIsDialogOpen(false);
      setFormData({
        chapterName: "",
        chapterDescription: ""
      });
      toast.success("Chapter created successfully");
    },
    onError: (error) => {
      toast.error(error.response?.data?.error || "Failed to create chapter");
    }
  });
  const updateMutation = useMutation({
    mutationFn: async (data) => {
      if (!editingChapter) return;
      const res = await _axios.put(`/chapters/${editingChapter._id}`, {
        courseId,
        chapterName: data.chapterName,
        chapterDescription: data.chapterDescription,
        order: data.order
      });
      return res.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["chapters", courseId]
      });
      setIsDialogOpen(false);
      setEditingChapter(null);
      setFormData({
        chapterName: "",
        chapterDescription: "",
        order: void 0
      });
      toast.success("Chapter updated successfully");
    },
    onError: (error) => {
      toast.error(error.response?.data?.error || "Failed to update chapter");
    }
  });
  const handleOpenDialog = (chapter) => {
    if (chapter) {
      setEditingChapter(chapter);
      setFormData({
        chapterName: chapter.chapterName,
        chapterDescription: chapter.chapterDescription || "",
        order: chapter.order
      });
    } else {
      setEditingChapter(null);
      setFormData({
        chapterName: "",
        chapterDescription: "",
        order: void 0
      });
    }
    setIsDialogOpen(true);
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingChapter) {
      updateMutation.mutate(formData);
    } else {
      createMutation.mutate(formData);
    }
  };
  console.log(chapters.length > 0, chapterId === "new", chapterId);
  if (chapters.length > 0 && chapterId === "new") {
    navigate({
      to: `/courses/${courseId}/chapters/${chapters[0]._id}`
    });
  }
  return /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsxs("div", { className: "p-2 flex flex-col", children: [
    /* @__PURE__ */ jsx("div", { className: "mb-3 flex justify-between items-center", children: /* @__PURE__ */ jsxs(Button, { onClick: () => navigate({
      to: "/courses",
      search: {
        page: 1,
        search: "",
        sortBy: "createdAt",
        sortOrder: "desc"
      }
    }), variant: "outline", className: "rounded-xsm hover:text-foreground text-foreground  cursor-pointer hover:bg-accent/50", children: [
      /* @__PURE__ */ jsx(ArrowBigLeft, { className: "mr-2 h-4 w-4" }),
      " Back to Courses"
    ] }) }),
    /* @__PURE__ */ jsxs("div", { className: "flex-1 grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-3 min-h-[75vh] overflow-auto", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col h-full bg-sidebar text-foreground", children: [
        /* @__PURE__ */ jsxs("header", { className: "flex justify-between items-center p-4 ", children: [
          /* @__PURE__ */ jsx("h5", { className: "font-medium ", children: "Chapters" }),
          /* @__PURE__ */ jsxs(Dialog, { open: isDialogOpen, onOpenChange: setIsDialogOpen, children: [
            /* @__PURE__ */ jsx(DialogTrigger, { asChild: true, children: /* @__PURE__ */ jsxs(Button, { onClick: () => handleOpenDialog(), className: " rounded-xsm cursor-pointer", children: [
              /* @__PURE__ */ jsx(Plus, { className: "mr-2 h-4 w-4" }),
              " Add Chapter"
            ] }) }),
            /* @__PURE__ */ jsxs(DialogContent, { className: "sm:max-w-[425px]", children: [
              /* @__PURE__ */ jsxs(DialogHeader, { children: [
                /* @__PURE__ */ jsx(DialogTitle, { children: editingChapter ? "Edit Chapter" : "Add New Chapter" }),
                /* @__PURE__ */ jsx(DialogDescription, { children: editingChapter ? "Update the chapter details below." : "Fill in the details to create a new chapter." })
              ] }),
              /* @__PURE__ */ jsxs("form", { onSubmit: handleSubmit, children: [
                /* @__PURE__ */ jsxs("div", { className: "grid gap-4 py-4", children: [
                  /* @__PURE__ */ jsxs("div", { className: "grid gap-2", children: [
                    /* @__PURE__ */ jsx(Label, { htmlFor: "chapterName", children: "Chapter Name" }),
                    /* @__PURE__ */ jsx(Input, { id: "chapterName", value: formData.chapterName, onChange: (e) => setFormData({
                      ...formData,
                      chapterName: e.target.value
                    }), className: "text-foreground h-10 rounded-xsm", placeholder: "Enter chapter name", required: true })
                  ] }),
                  /* @__PURE__ */ jsxs("div", { className: "grid gap-2", children: [
                    /* @__PURE__ */ jsx(Label, { htmlFor: "chapterDescription", children: "Description" }),
                    /* @__PURE__ */ jsx(Textarea, { id: "chapterDescription", value: formData.chapterDescription, onChange: (e) => setFormData({
                      ...formData,
                      chapterDescription: e.target.value
                    }), className: "text-foreground  rounded-xsm", placeholder: "Optional description", rows: 3 })
                  ] }),
                  /* @__PURE__ */ jsxs("div", { className: "grid gap-2", children: [
                    /* @__PURE__ */ jsx(Label, { htmlFor: "order", children: "Order" }),
                    /* @__PURE__ */ jsx(Input, { id: "order", type: "number", value: formData.order, className: "text-foreground h-10 rounded-xsm", onChange: (e) => setFormData({
                      ...formData,
                      order: Number(e.target.value)
                    }), placeholder: "Enter order", required: true })
                  ] })
                ] }),
                /* @__PURE__ */ jsxs(DialogFooter, { children: [
                  /* @__PURE__ */ jsx(DialogClose, { asChild: true, children: /* @__PURE__ */ jsx(Button, { className: "hover:text-foreground cursor-pointer rounded-xsm", variant: "outline", type: "button", children: "Cancel" }) }),
                  /* @__PURE__ */ jsx(
                    Button,
                    {
                      className: "hover:text-background! cursor-pointer text-background rounded-xsm px-5",
                      children: createMutation.isPending || updateMutation.isPending ? "Saving..." : "Create"
                    }
                  )
                ] })
              ] })
            ] })
          ] })
        ] }),
        chaptersLoading ? /* @__PURE__ */ jsx("div", { className: "p-4 text-center", children: "Loading chapters..." }) : /* @__PURE__ */ jsx("ul", { className: "flex-1 overflow-auto flex flex-col p-2 gap-3", children: chapters.length === 0 ? /* @__PURE__ */ jsx("li", { className: "p-4 text-center text-foreground", children: "No chapters yet. Add one to get started!" }) : chapters.map((chapter) => /* @__PURE__ */ jsxs("li", { className: `flex items-center justify-between p-3 bg-accent hover:bg-foreground/10 cursor-pointer ${chapter._id === chapterId ? "bg-accent border-foreground border-[0.1px] rounded-xsm" : ""}`, onClick: () => navigate({
          to: `/courses/${courseId}/chapters/${chapter._id}`
        }), children: [
          /* @__PURE__ */ jsx("span", { className: "capitalize", children: chapter.chapterName }),
          /* @__PURE__ */ jsx("div", { className: "", children: /* @__PURE__ */ jsx(Button, { variant: "ghost", size: "icon", onClick: (e) => {
            e.stopPropagation();
            handleOpenDialog(chapter);
          }, className: "cursor-pointer hover:text-foreground text-foreground", children: /* @__PURE__ */ jsx(Pencil, { className: "h-4 w-4" }) }) })
        ] }, chapter._id)) })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "flex flex-col h-full xl:col-span-2 bg-sidebar", children: /* @__PURE__ */ jsx(Outlet, {}) })
    ] })
  ] }) });
}
export {
  ChaptersPage as component
};
