import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { useLocation, useRouter, useNavigate } from "@tanstack/react-router";
import { useQueryClient, useQuery, useMutation } from "@tanstack/react-query";
import { c as createLucideIcon, f as Route$2, _ as _axios, B as Button, L as Label, e as LoaderCircle, b as cn } from "./router-nT5qf-VO.mjs";
import { I as Input } from "./input-B5eCZYSF.mjs";
import * as SelectPrimitive from "@radix-ui/react-select";
import { C as Card, a as CardContent, U as Upload } from "./card-5s5tvRno.mjs";
import { useState } from "react";
import { toast } from "sonner";
import { A as ArrowBigLeft } from "./arrow-big-left.mjs";
import { C as ChevronDown } from "./chevron-down.mjs";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "next-themes";
import "@radix-ui/react-tooltip";
import "axios";
import "@radix-ui/react-label";
const __iconNode$1 = [["path", { d: "M20 6 9 17l-5-5", key: "1gmf2c" }]];
const Check = createLucideIcon("check", __iconNode$1);
const __iconNode = [["path", { d: "m18 15-6-6-6 6", key: "153udz" }]];
const ChevronUp = createLucideIcon("chevron-up", __iconNode);
function Select({
  ...props
}) {
  return /* @__PURE__ */ jsx(SelectPrimitive.Root, { "data-slot": "select", ...props });
}
function SelectValue({
  ...props
}) {
  return /* @__PURE__ */ jsx(SelectPrimitive.Value, { "data-slot": "select-value", ...props });
}
function SelectTrigger({
  className,
  size = "default",
  children,
  ...props
}) {
  return /* @__PURE__ */ jsxs(
    SelectPrimitive.Trigger,
    {
      "data-slot": "select-trigger",
      "data-size": size,
      className: cn(
        "border-input data-[placeholder]:text-muted-foreground [&_svg:not([class*='text-'])]:text-muted-foreground focus-visible:border-ring focus-visible:ring-ring/50 aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive dark:bg-input/30 dark:hover:bg-input/50 flex w-fit items-center justify-between gap-2 rounded-md border bg-transparent px-3 py-2 text-sm whitespace-nowrap shadow-xs transition-[color,box-shadow] outline-none focus-visible:ring-[3px] disabled:cursor-not-allowed disabled:opacity-50 data-[size=default]:h-9 data-[size=sm]:h-8 *:data-[slot=select-value]:line-clamp-1 *:data-[slot=select-value]:flex *:data-[slot=select-value]:items-center *:data-[slot=select-value]:gap-2 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4",
        className
      ),
      ...props,
      children: [
        children,
        /* @__PURE__ */ jsx(SelectPrimitive.Icon, { asChild: true, children: /* @__PURE__ */ jsx(ChevronDown, { className: "size-4 opacity-50" }) })
      ]
    }
  );
}
function SelectContent({
  className,
  children,
  position = "item-aligned",
  align = "center",
  ...props
}) {
  return /* @__PURE__ */ jsx(SelectPrimitive.Portal, { children: /* @__PURE__ */ jsxs(
    SelectPrimitive.Content,
    {
      "data-slot": "select-content",
      className: cn(
        "bg-popover text-popover-foreground data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 relative z-50 max-h-(--radix-select-content-available-height) min-w-[8rem] origin-(--radix-select-content-transform-origin) overflow-x-hidden overflow-y-auto rounded-md border shadow-md",
        position === "popper" && "data-[side=bottom]:translate-y-1 data-[side=left]:-translate-x-1 data-[side=right]:translate-x-1 data-[side=top]:-translate-y-1",
        className
      ),
      position,
      align,
      ...props,
      children: [
        /* @__PURE__ */ jsx(SelectScrollUpButton, {}),
        /* @__PURE__ */ jsx(
          SelectPrimitive.Viewport,
          {
            className: cn(
              "p-1",
              position === "popper" && "h-[var(--radix-select-trigger-height)] w-full min-w-[var(--radix-select-trigger-width)] scroll-my-1"
            ),
            children
          }
        ),
        /* @__PURE__ */ jsx(SelectScrollDownButton, {})
      ]
    }
  ) });
}
function SelectItem({
  className,
  children,
  ...props
}) {
  return /* @__PURE__ */ jsxs(
    SelectPrimitive.Item,
    {
      "data-slot": "select-item",
      className: cn(
        "focus:bg-accent focus:text-accent-foreground [&_svg:not([class*='text-'])]:text-muted-foreground relative flex w-full cursor-default items-center gap-2 rounded-sm py-1.5 pr-8 pl-2 text-sm outline-hidden select-none data-[disabled]:pointer-events-none data-[disabled]:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4 *:[span]:last:flex *:[span]:last:items-center *:[span]:last:gap-2",
        className
      ),
      ...props,
      children: [
        /* @__PURE__ */ jsx(
          "span",
          {
            "data-slot": "select-item-indicator",
            className: "absolute right-2 flex size-3.5 items-center justify-center",
            children: /* @__PURE__ */ jsx(SelectPrimitive.ItemIndicator, { children: /* @__PURE__ */ jsx(Check, { className: "size-4" }) })
          }
        ),
        /* @__PURE__ */ jsx(SelectPrimitive.ItemText, { children })
      ]
    }
  );
}
function SelectScrollUpButton({
  className,
  ...props
}) {
  return /* @__PURE__ */ jsx(
    SelectPrimitive.ScrollUpButton,
    {
      "data-slot": "select-scroll-up-button",
      className: cn(
        "flex cursor-default items-center justify-center py-1",
        className
      ),
      ...props,
      children: /* @__PURE__ */ jsx(ChevronUp, { className: "size-4" })
    }
  );
}
function SelectScrollDownButton({
  className,
  ...props
}) {
  return /* @__PURE__ */ jsx(
    SelectPrimitive.ScrollDownButton,
    {
      "data-slot": "select-scroll-down-button",
      className: cn(
        "flex cursor-default items-center justify-center py-1",
        className
      ),
      ...props,
      children: /* @__PURE__ */ jsx(ChevronDown, { className: "size-4" })
    }
  );
}
function CreateCoursePage() {
  const {
    id
  } = Route$2.useParams();
  const location = useLocation();
  const router = useRouter();
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const isEditMode = id !== "new";
  const stateCourse = isEditMode ? location.state?.course : null;
  const getInitialFormData = () => {
    if (isEditMode && stateCourse) {
      return {
        courseName: stateCourse.courseName || "",
        mentor: stateCourse.mentor?.id || stateCourse.mentor?._id || "",
        courseDurationMinutes: String(stateCourse.courseDurationMinutes || ""),
        strikePrice: String(stateCourse.strikePrice || ""),
        actualPrice: String(stateCourse.actualPrice || ""),
        board: stateCourse.board?.id || "",
        grade: stateCourse.grade?.id || "",
        bannerImage: null
      };
    }
    return {
      courseName: "",
      mentor: "",
      courseDurationMinutes: "",
      strikePrice: "",
      actualPrice: "",
      board: "",
      grade: "",
      bannerImage: null
    };
  };
  const [formData, setFormData] = useState(getInitialFormData());
  const [errors, setErrors] = useState({});
  const [previewImage, setPreviewImage] = useState(isEditMode && stateCourse?.bannerImage ? stateCourse.bannerImage : null);
  const goBack = () => {
    router.history.back();
  };
  const {
    data: mentors = [],
    isLoading: mentorsLoading
  } = useQuery({
    queryKey: ["mentors"],
    queryFn: async () => {
      const res = await _axios.get("/staffs");
      return res.data.staffs || res.data;
    }
  });
  const {
    data: boards = [],
    isLoading: boardsLoading
  } = useQuery({
    queryKey: ["boards"],
    queryFn: async () => {
      const res = await _axios.get("/boards");
      return res.data.boards || res.data;
    }
  });
  const {
    data: grades = [],
    isLoading: gradesLoading
  } = useQuery({
    queryKey: ["grades"],
    queryFn: async () => {
      const res = await _axios.get("/grades");
      return res.data.grades || res.data;
    }
  });
  const mutation = useMutation({
    mutationFn: async () => {
      const data = new FormData();
      data.append("courseName", formData.courseName);
      if (formData.mentor) data.append("mentor", formData.mentor);
      data.append("strikePrice", formData.strikePrice);
      data.append("actualPrice", formData.actualPrice);
      data.append("board", formData.board);
      data.append("grade", formData.grade);
      data.append("courseDurationMinutes", formData.courseDurationMinutes);
      if (formData.bannerImage) {
        data.append("bannerImage", formData.bannerImage);
      }
      if (isEditMode) {
        return _axios.put(`/courses/${id}`, data);
      } else {
        return _axios.post("/courses", data);
      }
    },
    onSuccess: () => {
      toast.success(isEditMode ? "Course updated successfully" : "Course created successfully");
      queryClient.invalidateQueries({
        queryKey: ["courses"]
      });
      goBack();
    },
    onError: (error) => {
      toast.error(error.response?.data?.message || "Operation failed");
    }
  });
  const validateForm = () => {
    const newErrors = {};
    if (!formData.courseName.trim()) {
      newErrors.courseName = "Course name is required";
    } else if (formData.courseName.length < 3 || formData.courseName.length > 100) {
      newErrors.courseName = "Course name must be between 3 and 100 characters";
    }
    if (!formData.mentor.trim()) {
      newErrors.mentor = "please select a mentor";
    }
    if (!formData.strikePrice.trim()) {
      newErrors.strikePrice = "Strike price is required";
    } else if (!/^\d+$/.test(formData.strikePrice)) {
      newErrors.strikePrice = "Strike price must be a valid number";
    }
    if (!formData.actualPrice.trim()) {
      newErrors.actualPrice = "Actual price is required";
    } else if (!/^\d+$/.test(formData.actualPrice)) {
      newErrors.actualPrice = "Actual price must be a valid number";
    }
    if (!formData.board) {
      newErrors.board = "Please select a board";
    }
    if (!formData.grade) {
      newErrors.grade = "Please select a grade";
    }
    if (!isEditMode && !formData.bannerImage) {
      newErrors.bannerImage = "Banner image is required";
    } else if (formData.bannerImage) {
      const file = formData.bannerImage;
      if (file.size > 5 * 1024 * 1024) {
        newErrors.bannerImage = "Max file size is 5MB";
      }
      if (!["image/jpeg", "image/jpg", "image/png", "image/webp"].includes(file.type)) {
        newErrors.bannerImage = "Only .jpg, .jpeg, .png and .webp formats are supported";
      }
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleInputChange = (e) => {
    const {
      name,
      value
    } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
    if (errors[name]) {
      setErrors((prev) => ({
        ...prev,
        [name]: ""
      }));
    }
  };
  const handleSelectChange = (name, value) => {
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
    if (errors[name]) {
      setErrors((prev) => ({
        ...prev,
        [name]: ""
      }));
    }
  };
  const handleFileChange = (e) => {
    const file = e.target.files?.[0];
    if (file) {
      setFormData((prev) => ({
        ...prev,
        bannerImage: file
      }));
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewImage(reader.result);
      };
      reader.readAsDataURL(file);
    }
    if (errors.bannerImage) {
      setErrors((prev) => ({
        ...prev,
        bannerImage: ""
      }));
    }
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    if (validateForm()) {
      mutation.mutate();
    }
  };
  return /* @__PURE__ */ jsxs("div", { className: "mx-auto p-2", children: [
    /* @__PURE__ */ jsxs(Button, { onClick: () => navigate({
      to: "/courses",
      search: {
        page: 1,
        search: "",
        sortBy: "createdAt",
        sortOrder: "desc"
      }
    }), variant: "outline", className: "rounded-xsm hover:text-foreground text-foreground  cursor-pointer hover:bg-accent/50 my-2", children: [
      /* @__PURE__ */ jsx(ArrowBigLeft, { className: "mr-2 h-4 w-4" }),
      " Back to Courses"
    ] }),
    /* @__PURE__ */ jsx(Card, { className: "rounded-xsm border-background", children: /* @__PURE__ */ jsx(CardContent, { children: /* @__PURE__ */ jsxs("form", { onSubmit: handleSubmit, className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-5", children: [
        /* @__PURE__ */ jsx(Label, { className: "text-foreground", htmlFor: "courseName", children: "Course Name" }),
        /* @__PURE__ */ jsx(Input, { id: "courseName", name: "courseName", className: "text-foreground h-10 rounded-xsm", value: formData.courseName, onChange: handleInputChange, placeholder: "e.g. Complete React Mastery" }),
        errors.courseName && /* @__PURE__ */ jsx("p", { className: "text-sm text-destructive", children: errors.courseName })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-5", children: [
        /* @__PURE__ */ jsx(Label, { className: "text-foreground", htmlFor: "courseDurationMinutes", children: "Course Duration(minutes)" }),
        /* @__PURE__ */ jsx(Input, { id: "courseDurationMinutes", type: "number", name: "courseDurationMinutes", className: "text-foreground h-10 rounded-xsm", value: formData.courseDurationMinutes, onChange: handleInputChange, placeholder: "e.g. 90" }),
        errors.courseDurationMinutes && /* @__PURE__ */ jsx("p", { className: "text-sm text-destructive", children: errors.courseDurationMinutes })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-5 h-full", children: [
        /* @__PURE__ */ jsx(Label, { className: "text-foreground", children: "Mentor" }),
        /* @__PURE__ */ jsxs(Select, { value: formData.mentor, onValueChange: (value) => handleSelectChange("mentor", value), disabled: mentorsLoading, children: [
          /* @__PURE__ */ jsx(SelectTrigger, { className: "w-full h-10! rounded-xsm text-foreground", children: /* @__PURE__ */ jsx(SelectValue, { placeholder: mentorsLoading ? "Loading mentors..." : "Select a mentor" }) }),
          /* @__PURE__ */ jsx(SelectContent, { className: "bg-background", children: mentors?.map((mentor) => /* @__PURE__ */ jsx(SelectItem, { className: "hover:text-foreground! cursor-pointer", value: mentor._id, children: /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2 text-foreground", children: [
            /* @__PURE__ */ jsx("img", { src: mentor.image, alt: mentor.staffName, className: "h-6 w-6 rounded-full object-cover" }),
            /* @__PURE__ */ jsx("span", { children: mentor.staffName })
          ] }) }, mentor._id)) })
        ] }),
        errors.mentor && /* @__PURE__ */ jsx("p", { className: "text-sm text-destructive", children: errors.mentor })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-5", children: [
        /* @__PURE__ */ jsx(Label, { className: "text-foreground", htmlFor: "strikePrice", children: "Strike Price (₹)" }),
        /* @__PURE__ */ jsx(Input, { id: "strikePrice", name: "strikePrice", type: "number", className: "text-foreground h-10 rounded-xsm", value: formData.strikePrice, onChange: handleInputChange, placeholder: "2999" }),
        errors.strikePrice && /* @__PURE__ */ jsx("p", { className: "text-sm text-destructive", children: errors.strikePrice })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-5", children: [
        /* @__PURE__ */ jsx(Label, { className: "text-foreground", htmlFor: "actualPrice", children: "Actual Price (₹)" }),
        /* @__PURE__ */ jsx(Input, { id: "actualPrice", name: "actualPrice", type: "number", className: "text-foreground h-10 rounded-xsm", value: formData.actualPrice, onChange: handleInputChange, placeholder: "999" }),
        errors.actualPrice && /* @__PURE__ */ jsx("p", { className: "text-sm text-destructive", children: errors.actualPrice })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-5 h-full", children: [
        /* @__PURE__ */ jsx(Label, { className: "text-foreground", children: "Board" }),
        /* @__PURE__ */ jsxs(Select, { value: formData.board, onValueChange: (value) => handleSelectChange("board", value), disabled: boardsLoading, children: [
          /* @__PURE__ */ jsx(SelectTrigger, { className: "w-full h-10! rounded-xsm text-foreground", children: /* @__PURE__ */ jsx(SelectValue, { placeholder: boardsLoading ? "Loading boards..." : "Select a board" }) }),
          /* @__PURE__ */ jsx(SelectContent, { className: "bg-background", children: boards?.map((board) => /* @__PURE__ */ jsx(SelectItem, { className: "hover:text-foreground! cursor-pointer", value: board._id, children: board.boardName }, board._id)) })
        ] }),
        errors.board && /* @__PURE__ */ jsx("p", { className: "text-sm text-destructive", children: errors.board })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-5 h-full", children: [
        /* @__PURE__ */ jsx(Label, { className: "text-foreground", children: "Grade" }),
        /* @__PURE__ */ jsxs(Select, { value: formData.grade, onValueChange: (value) => handleSelectChange("grade", value), disabled: gradesLoading, children: [
          /* @__PURE__ */ jsx(SelectTrigger, { className: "w-full h-10! rounded-xsm text-foreground", children: /* @__PURE__ */ jsx(SelectValue, { placeholder: gradesLoading ? "Loading grade..." : "Select a grade" }) }),
          /* @__PURE__ */ jsx(SelectContent, { className: "bg-background", children: grades?.map((grades2) => /* @__PURE__ */ jsx(SelectItem, { className: "hover:text-foreground! cursor-pointer", value: grades2._id, children: grades2.grade }, grades2._id)) })
        ] }),
        errors.grades && /* @__PURE__ */ jsx("p", { className: "text-sm text-destructive", children: errors.board })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-5 col-span-full", children: [
        /* @__PURE__ */ jsx(Label, { className: "text-foreground", htmlFor: "banner-image", children: "Banner Image" }),
        /* @__PURE__ */ jsxs("div", { className: "grid w-full max-w-full bg-background! items-center gap-1.5", children: [
          /* @__PURE__ */ jsx(Label, { htmlFor: "banner-image", className: `flex flex-col items-center justify-center w-full h-64 ${previewImage ? `` : `border-2 border-dashed`} rounded-xsm cursor-pointer`, children: previewImage ? /* @__PURE__ */ jsx("img", { src: previewImage, alt: "Preview", className: "w-full h-full object-cover rounded-lg" }) : /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-center justify-center pt-5 pb-6", children: [
            /* @__PURE__ */ jsx(Upload, { className: "w-10 h-10 mb-3 text-gray-400" }),
            /* @__PURE__ */ jsxs("p", { className: "mb-2 text-sm text-gray-500", children: [
              /* @__PURE__ */ jsx("span", { className: "font-semibold", children: "Click to upload" }),
              " ",
              "or drag and drop"
            ] }),
            /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-500", children: "PNG, JPG, JPEG up to 5MB" })
          ] }) }),
          /* @__PURE__ */ jsx(Input, { id: "banner-image", type: "file", accept: "image/*", className: "hidden", onChange: handleFileChange })
        ] }),
        formData.bannerImage && /* @__PURE__ */ jsxs("p", { className: "text-sm text-foreground mt-2", children: [
          "Selected: ",
          formData.bannerImage.name
        ] }),
        errors.bannerImage && /* @__PURE__ */ jsx("p", { className: "text-sm text-destructive", children: errors.bannerImage })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "flex gap-4 col-span-full justify-end", children: /* @__PURE__ */ jsx(Button, { type: "submit", disabled: mutation.isPending, className: "w-full rounded-xsm bg-foreground text-background hover:bg-foreground/90 hover:text-background cursor-pointer sm:w-auto", children: mutation.isPending ? /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsx(LoaderCircle, { className: "mr-2 h-4 w-4 animate-spin" }),
        isEditMode ? "Updating..." : "Creating..."
      ] }) : isEditMode ? "Update Course" : "Create Course" }) })
    ] }) }) })
  ] });
}
export {
  CreateCoursePage as component
};
