import { c as createLucideIcon, b as cn } from "./router-nT5qf-VO.mjs";
import { jsxs, jsx } from "react/jsx-runtime";
const __iconNode$1 = [["path", { d: "m15 18-6-6 6-6", key: "1wnfg3" }]];
const ChevronLeft = createLucideIcon("chevron-left", __iconNode$1);
const __iconNode = [["path", { d: "m9 18 6-6-6-6", key: "mthhwq" }]];
const ChevronRight = createLucideIcon("chevron-right", __iconNode);
function Skeleton({ className, ...props }) {
  return /* @__PURE__ */ jsx(
    "div",
    {
      "data-slot": "skeleton",
      className: cn("bg-accent animate-pulse rounded-md", className),
      ...props
    }
  );
}
function CourseTableSkeleton() {
  return /* @__PURE__ */ jsxs("div", { className: "mx-auto p-2", children: [
    /* @__PURE__ */ jsx("div", { className: "rounded-xsm bg-sidebar shadow-sm", children: /* @__PURE__ */ jsxs("table", { className: "w-full table-auto", children: [
      /* @__PURE__ */ jsx("thead", { className: "border-b", children: /* @__PURE__ */ jsxs("tr", { children: [
        /* @__PURE__ */ jsx("th", { className: "px-3 py-4 text-left border-[0.5px] border-background", children: /* @__PURE__ */ jsx(Skeleton, { className: "h-5 w-32 bg-gray-200" }) }),
        /* @__PURE__ */ jsx("th", { className: "px-3 py-4 text-left border-[0.5px] border-background", children: /* @__PURE__ */ jsx(Skeleton, { className: "h-5 w-20 bg-gray-200" }) }),
        /* @__PURE__ */ jsx("th", { className: "px-3 py-4 text-left border-[0.5px] border-background", children: /* @__PURE__ */ jsx(Skeleton, { className: "h-5 w-16 bg-gray-200" }) }),
        /* @__PURE__ */ jsx("th", { className: "px-3 py-4 text-left border-[0.5px] border-background", children: /* @__PURE__ */ jsx(Skeleton, { className: "h-5 w-28 bg-gray-200" }) })
      ] }) }),
      /* @__PURE__ */ jsx("tbody", { children: [...Array(10)].map((_, i) => (
        // 10 rows to match your limit
        /* @__PURE__ */ jsxs("tr", { className: "hover:bg-background animate-pulse", children: [
          /* @__PURE__ */ jsx("td", { className: "px-3 py-2 border-[0.5px] border-background", children: /* @__PURE__ */ jsx(Skeleton, { className: "h-5 w-48 bg-gray-200" }) }),
          /* @__PURE__ */ jsx("td", { className: "px-3 py-2 border-[0.5px] border-background", children: /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsx(Skeleton, { className: "h-10 w-10 rounded-full bg-gray-200" }),
            /* @__PURE__ */ jsx(Skeleton, { className: "h-5 w-32 bg-gray-200" })
          ] }) }),
          /* @__PURE__ */ jsx("td", { className: "px-3 py-2 border-[0.5px] border-background", children: /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx(Skeleton, { className: "h-6 w-20 bg-gray-200" }),
            /* @__PURE__ */ jsx(Skeleton, { className: "h-5 w-16 bg-gray-200" })
          ] }) }),
          /* @__PURE__ */ jsx("td", { className: "px-3 py-2 border-[0.5px] border-background", children: /* @__PURE__ */ jsx(Skeleton, { className: "h-5 w-24 bg-gray-200" }) })
        ] }, i)
      )) })
    ] }) }),
    /* @__PURE__ */ jsxs("div", { className: "mt-6 flex items-center justify-between", children: [
      /* @__PURE__ */ jsx(Skeleton, { className: "h-5 w-64 bg-gray-200" }),
      /* @__PURE__ */ jsxs("div", { className: "flex gap-2", children: [
        /* @__PURE__ */ jsx(Skeleton, { className: "h-10 w-28 bg-gray-200" }),
        /* @__PURE__ */ jsx(Skeleton, { className: "h-10 w-24 bg-gray-200" })
      ] })
    ] })
  ] });
}
export {
  CourseTableSkeleton as C,
  ChevronLeft as a,
  ChevronRight as b
};
