import { jsx, jsxs } from "react/jsx-runtime";
import { useQuery } from "@tanstack/react-query";
import { c as createLucideIcon, a as Route$4, _ as _axios, B as Button, E as Eye } from "./router-nT5qf-VO.mjs";
import { useReactTable, getPaginationRowModel, getFilteredRowModel, getSortedRowModel, getCoreRowModel, flexRender } from "@tanstack/react-table";
import { useState } from "react";
import { useSearch } from "@tanstack/react-router";
import { format } from "date-fns";
import { I as Input } from "./input-B5eCZYSF.mjs";
import { C as CourseTableSkeleton, a as ChevronLeft, b as ChevronRight } from "./TableSkeleton-D58uHf2v.mjs";
import { P as Plus } from "./plus.mjs";
import { P as Pencil } from "./pencil.mjs";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "next-themes";
import "sonner";
import "@radix-ui/react-tooltip";
import "axios";
import "@radix-ui/react-label";
const __iconNode = [
  ["path", { d: "m21 16-4 4-4-4", key: "f6ql7i" }],
  ["path", { d: "M17 20V4", key: "1ejh1v" }],
  ["path", { d: "m3 8 4-4 4 4", key: "11wl7u" }],
  ["path", { d: "M7 4v16", key: "1glfcx" }]
];
const ArrowUpDown = createLucideIcon("arrow-up-down", __iconNode);
function CoursesPage() {
  const navigate = Route$4.useNavigate();
  const search = useSearch({
    from: "/courses/"
  });
  const {
    page = 1,
    search: searchTerm = "",
    sortBy = "createdAt",
    sortOrder = "desc"
  } = search;
  const [sorting, setSorting] = useState([{
    id: sortBy,
    desc: sortOrder === "desc"
  }]);
  const [columnFilters, setColumnFilters] = useState([]);
  const [columnVisibility, setColumnVisibility] = useState({});
  const {
    data,
    isLoading,
    error
  } = useQuery({
    queryKey: ["courses", {
      page,
      search: searchTerm,
      sortBy,
      sortOrder
    }],
    queryFn: async () => {
      const params = new URLSearchParams({
        page: String(page),
        limit: "10",
        search: searchTerm,
        sortBy,
        sortOrder
      });
      const res = await _axios.get(`/courses?${params.toString()}`);
      return res.data;
    }
  });
  const courses = data?.courses ?? [];
  const pagination = data?.pagination;
  const columns = [{
    accessorKey: "courseName",
    header: ({
      column
    }) => /* @__PURE__ */ jsxs("button", { className: "flex items-center gap-1 font-medium", onClick: () => column.toggleSorting(column.getIsSorted() === "asc"), children: [
      "Course Name",
      /* @__PURE__ */ jsx(ArrowUpDown, { className: "h-4 w-4" })
    ] }),
    cell: ({
      row
    }) => /* @__PURE__ */ jsx("div", { className: "font-medium", children: row.original.courseName })
  }, {
    accessorKey: "mentor.staffName",
    header: "Mentor",
    cell: ({
      row
    }) => /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
      /* @__PURE__ */ jsx("img", { src: row.original.mentor.image, alt: row.original.mentor.staffName, className: "h-10 w-10 rounded-full object-cover" }),
      /* @__PURE__ */ jsx("span", { children: row.original.mentor.staffName })
    ] })
  }, {
    accessorKey: "board",
    header: "Board",
    cell: ({
      row
    }) => /* @__PURE__ */ jsx("div", { className: "font-medium", children: row.original.board.name })
  }, {
    accessorKey: "grade",
    header: "Grade",
    cell: ({
      row
    }) => /* @__PURE__ */ jsx("div", { className: "font-medium", children: row.original.grade.name })
  }, {
    accessorKey: "actualPrice",
    header: "Price",
    cell: ({
      row
    }) => /* @__PURE__ */ jsxs("div", { children: [
      /* @__PURE__ */ jsxs("span", { className: "text-lg font-bold text-foreground", children: [
        "₹",
        row.original.actualPrice
      ] }),
      row.original.strikePrice !== row.original.actualPrice && /* @__PURE__ */ jsxs("span", { className: "ml-2 text-sm text-gray-500 line-through", children: [
        "₹",
        row.original.strikePrice
      ] })
    ] })
  }, {
    accessorKey: "createdAt",
    header: ({
      column
    }) => /* @__PURE__ */ jsxs("button", { className: "flex items-center gap-1 font-medium", onClick: () => column.toggleSorting(column.getIsSorted() === "asc"), children: [
      "Created At",
      /* @__PURE__ */ jsx(ArrowUpDown, { className: "h-4 w-4" })
    ] }),
    cell: ({
      row
    }) => format(new Date(row.original.createdAt), "MMM dd, yyyy")
  }, {
    id: "actions",
    header: "Actions",
    cell: ({
      row
    }) => {
      const course = row.original;
      return /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsx("button", { onClick: () => navigate({
          to: `/courses/$id`,
          params: {
            id: course._id
          },
          state: {
            course
          }
        }), className: "p-2 rounded-md cursor-pointer text-foreground transition-colors", title: "Edit course", children: /* @__PURE__ */ jsx(Pencil, { className: "h-4 w-4 text-foreground" }) }),
        /* @__PURE__ */ jsx("button", { onClick: () => navigate({
          to: `/courses/$id/chapters/$chapterId`,
          params: {
            id: course._id,
            chapterId: "new"
          }
        }), className: "p-2 rounded-md cursor-pointer text-foreground transition-colors", title: "Edit course", children: /* @__PURE__ */ jsx(Eye, { className: "h-4 w-4 text-foreground" }) })
      ] });
    }
  }];
  const table = useReactTable({
    data: courses,
    columns,
    onSortingChange: setSorting,
    onColumnFiltersChange: setColumnFilters,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    state: {
      sorting,
      columnFilters,
      columnVisibility
    },
    manualPagination: true,
    pageCount: pagination?.totalPages ?? -1
  });
  return /* @__PURE__ */ jsxs("div", { className: " mx-auto p-2", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex justify-end gap-3", children: [
      /* @__PURE__ */ jsx(Input, { type: "text", name: "course-search", placeholder: "Search courses...", value: searchTerm, onChange: (e) => navigate({
        search: (prev) => ({
          ...prev,
          search: e.target.value,
          page: 1
        }),
        replace: true
      }), className: "mb-6 w-full max-w-sm border border-foreground px-4 py-2 \n             focus-visible:outline-none focus-visible:ring-0 focus-visible:shadow-none \n             focus-visible::border-none transition-colors h-10 rounded-xsm" }),
      /* @__PURE__ */ jsxs(Button, { onClick: () => navigate({
        to: "/courses/$id",
        params: {
          id: "new"
        }
      }), className: "h-10 cursor-pointer text-background rounded-xsm", children: [
        /* @__PURE__ */ jsx(Plus, {}),
        " Create Course"
      ] })
    ] }),
    isLoading ? /* @__PURE__ */ jsx(CourseTableSkeleton, {}) : /* @__PURE__ */ jsx("div", { className: "rounded-xsm  bg-sidebar shadow-sm", children: /* @__PURE__ */ jsxs("table", { className: "w-full table-auto", children: [
      /* @__PURE__ */ jsx("thead", { className: "border-b ", children: table.getHeaderGroups().map((headerGroup) => /* @__PURE__ */ jsx("tr", { children: headerGroup.headers.map((header) => /* @__PURE__ */ jsx("th", { className: "px-3 py-4 text-left border-[0.5px] border-background text-sm font-medium text-foreground", children: header.isPlaceholder ? null : flexRender(header.column.columnDef.header, header.getContext()) }, header.id)) }, headerGroup.id)) }),
      /* @__PURE__ */ jsx("tbody", { children: table.getRowModel().rows.length === 0 ? /* @__PURE__ */ jsx("tr", { children: /* @__PURE__ */ jsx("td", { colSpan: columns.length, className: "px-6 py-12 text-center text-foreground", children: "No courses found" }) }) : table.getRowModel().rows.map((row) => /* @__PURE__ */ jsx("tr", { className: " hover:bg-background", children: row.getVisibleCells().map((cell) => /* @__PURE__ */ jsx("td", { className: "px-3 py-2 border-[0.5px] border-background hover:bg-secondary-background", children: flexRender(cell.column.columnDef.cell, cell.getContext()) }, cell.id)) }, row.id)) })
    ] }) }),
    pagination && pagination.totalPages > 1 && /* @__PURE__ */ jsxs("div", { className: "mt-6 flex items-center justify-between", children: [
      /* @__PURE__ */ jsxs("div", { className: "text-sm text-gray-600", children: [
        "Showing page ",
        pagination.page,
        " of ",
        pagination.totalPages,
        " (",
        pagination.total,
        " total)"
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex gap-2", children: [
        /* @__PURE__ */ jsxs("button", { onClick: () => navigate({
          search: (prev) => ({
            ...prev,
            page: page - 1
          })
        }), disabled: !pagination.hasPrevPage, className: "flex items-center gap-2 rounded-lg border px-4 py-2 disabled:cursor-not-allowed disabled:opacity-50 hover:bg-gray-50", children: [
          /* @__PURE__ */ jsx(ChevronLeft, { className: "h-4 w-4" }),
          "Previous"
        ] }),
        /* @__PURE__ */ jsxs("button", { onClick: () => navigate({
          search: (prev) => ({
            ...prev,
            page: page + 1
          })
        }), disabled: !pagination.hasNextPage, className: "flex items-center gap-2 rounded-lg border px-4 py-2 disabled:cursor-not-allowed disabled:opacity-50 hover:bg-gray-50", children: [
          "Next",
          /* @__PURE__ */ jsx(ChevronRight, { className: "h-4 w-4" })
        ] })
      ] })
    ] })
  ] });
}
export {
  CoursesPage as component
};
