import { jsx, jsxs, Fragment } from "react/jsx-runtime";
import { useLocation, useRouter } from "@tanstack/react-router";
import { useQueryClient, useMutation } from "@tanstack/react-query";
import { d as Route$3, _ as _axios, L as Label, B as Button, e as LoaderCircle } from "./router-nT5qf-VO.mjs";
import { I as Input } from "./input-B5eCZYSF.mjs";
import { C as Card, a as CardContent, U as Upload } from "./card-5s5tvRno.mjs";
import { useState, useEffect } from "react";
import { toast } from "sonner";
import "@radix-ui/react-slot";
import "class-variance-authority";
import "clsx";
import "tailwind-merge";
import "next-themes";
import "@radix-ui/react-tooltip";
import "axios";
import "@radix-ui/react-label";
function CreateMentorPage() {
  const {
    id
  } = Route$3.useParams();
  const location = useLocation();
  const router = useRouter();
  const queryClient = useQueryClient();
  const isEditMode = id !== "new";
  const stateStaff = isEditMode ? location.state?.mentor : null;
  const [formData, setFormData] = useState({
    staffName: "",
    phoneNumber: "",
    image: null
  });
  const [errors, setErrors] = useState({});
  const [previewImage, setPreviewImage] = useState(null);
  const goBack = () => {
    router.history.back();
  };
  useEffect(() => {
    if (isEditMode && stateStaff) {
      setFormData({
        staffName: stateStaff.staffName || "",
        phoneNumber: stateStaff.phoneNumber || "",
        image: null
      });
      setPreviewImage(stateStaff.image || null);
    }
  }, [isEditMode, stateStaff]);
  const mutation = useMutation({
    mutationFn: async () => {
      const data = new FormData();
      data.append("staffName", formData.staffName);
      data.append("phoneNumber", formData.phoneNumber);
      if (formData.image) data.append("image", formData.image);
      else if (isEditMode && typeof previewImage === "string" && previewImage) data.append("image", previewImage || "");
      if (isEditMode) {
        return _axios.put(`/staffs/${id}`, data);
      } else {
        return _axios.post("/staffs", data);
      }
    },
    onSuccess: () => {
      toast.success(isEditMode ? "Mentor updated successfully" : "Mentor created successfully");
      queryClient.invalidateQueries({
        queryKey: ["mentors"]
      });
      goBack();
    },
    onError: (error) => {
      toast.error(error.response?.data?.message || "Operation failed");
    }
  });
  const validateForm = () => {
    const newErrors = {};
    if (!formData.staffName.trim()) {
      newErrors.staffName = "Mentor name is required";
    } else if (formData.staffName.length < 3 || formData.staffName.length > 100) {
      newErrors.staffName = "Mentor name must be between 3 and 100 characters";
    }
    if (!formData.phoneNumber.trim()) {
      newErrors.phoneNumber = "Phone number is required";
    } else if (!/^\d+$/.test(formData.phoneNumber)) {
      newErrors.phoneNumber = "Phone number must be a valid number";
    }
    if (!isEditMode && !formData.image) {
      newErrors.image = " image is required";
    } else if (formData.image) {
      const file = formData.image;
      if (file.size > 5 * 1024 * 1024) {
        newErrors.image = "Max file size is 5MB";
      }
      if (!["image/jpeg", "image/jpg", "image/png", "image/webp"].includes(file.type)) {
        newErrors.image = "Only .jpg, .jpeg, .png and .webp formats are supported";
      }
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleInputChange = (e) => {
    const {
      name,
      value
    } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
    if (errors[name]) {
      setErrors((prev) => ({
        ...prev,
        [name]: ""
      }));
    }
  };
  const handleFileChange = (e) => {
    const file = e.target.files?.[0];
    if (file) {
      setFormData((prev) => ({
        ...prev,
        image: file
      }));
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewImage(reader.result);
      };
      reader.readAsDataURL(file);
    }
    if (errors.image) {
      setErrors((prev) => ({
        ...prev,
        image: ""
      }));
    }
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    if (validateForm()) {
      mutation.mutate();
    }
  };
  return /* @__PURE__ */ jsx("div", { className: "mx-auto p-2", children: /* @__PURE__ */ jsx(Card, { className: "rounded-xsm border-background", children: /* @__PURE__ */ jsx(CardContent, { children: /* @__PURE__ */ jsxs("form", { onSubmit: handleSubmit, className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-5", children: [
      /* @__PURE__ */ jsx(Label, { className: "text-foreground", htmlFor: "staffName", children: "Mentor Name" }),
      /* @__PURE__ */ jsx(Input, { id: "staffName", name: "staffName", className: "text-foreground h-10 rounded-xsm", value: formData.staffName, onChange: handleInputChange }),
      errors.staffName && /* @__PURE__ */ jsx("p", { className: "text-sm text-destructive", children: errors.staffName })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-5", children: [
      /* @__PURE__ */ jsx(Label, { className: "text-foreground", htmlFor: "phoneNumber", children: "Phone Number" }),
      /* @__PURE__ */ jsx(Input, { id: "phoneNumber", name: "phoneNumber", type: "number", className: "text-foreground h-10 rounded-xsm", value: formData.phoneNumber, onChange: handleInputChange }),
      errors.phoneNumber && /* @__PURE__ */ jsx("p", { className: "text-sm text-destructive", children: errors.phoneNumber })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-5 col-span-full", children: [
      /* @__PURE__ */ jsx(Label, { className: "text-foreground", htmlFor: "mentor-image", children: "Mentor Image" }),
      /* @__PURE__ */ jsxs("div", { className: "grid w-full max-w-full bg-background! items-center gap-1.5", children: [
        /* @__PURE__ */ jsx(Label, { htmlFor: "mentor-image", className: `flex flex-col items-center justify-center w-full h-64 ${previewImage ? `` : `border-2 border-dashed`} rounded-xsm cursor-pointer`, children: previewImage ? /* @__PURE__ */ jsx("img", { src: previewImage, alt: "Preview", className: "w-full h-full object-cover rounded-lg" }) : /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-center justify-center pt-5 pb-6", children: [
          /* @__PURE__ */ jsx(Upload, { className: "w-10 h-10 mb-3 text-gray-400" }),
          /* @__PURE__ */ jsxs("p", { className: "mb-2 text-sm text-gray-500", children: [
            /* @__PURE__ */ jsx("span", { className: "font-semibold", children: "Click to upload" }),
            " ",
            "or drag and drop"
          ] }),
          /* @__PURE__ */ jsx("p", { className: "text-xs text-gray-500", children: "PNG, JPG, JPEG up to 5MB" })
        ] }) }),
        /* @__PURE__ */ jsx(Input, { id: "mentor-image", type: "file", accept: "image/*", className: "hidden", onChange: handleFileChange })
      ] }),
      formData.image && /* @__PURE__ */ jsxs("p", { className: "text-sm text-foreground mt-2", children: [
        "Selected: ",
        formData.image.name
      ] }),
      errors.image && /* @__PURE__ */ jsx("p", { className: "text-sm text-destructive", children: errors.image })
    ] }),
    /* @__PURE__ */ jsx("div", { className: "flex gap-4 col-span-full justify-end", children: /* @__PURE__ */ jsx(Button, { type: "submit", disabled: mutation.isPending, className: "w-full rounded-xsm bg-foreground text-background hover:bg-foreground/90 hover:text-background cursor-pointer sm:w-auto", children: mutation.isPending ? /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx(LoaderCircle, { className: "mr-2 h-4 w-4 animate-spin" }),
      isEditMode ? "Updating..." : "Creating..."
    ] }) : isEditMode ? "Update Mentor" : "Create Mentor" }) })
  ] }) }) }) });
}
export {
  CreateMentorPage as component
};
