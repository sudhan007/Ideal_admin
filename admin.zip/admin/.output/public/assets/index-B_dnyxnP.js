import{j as o}from"./main-CzcXHWCU.js";function t(){return o.jsx("div",{children:'Hello "/"!'})}export{t as component};
